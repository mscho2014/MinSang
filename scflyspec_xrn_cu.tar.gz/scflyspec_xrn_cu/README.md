# scflyspec_xrn for copper (Z = 29)

This package computes copper spectra from SCFLY populations using the FLYSPEC
line list `xrn.29` instead of the SCFLY detailed transition files (`trn.29II`).
The line list covers all bands, from EUV through L-shell up to K-alpha.

`scflyspec_xrn` is a modified copy of the standard SCFLY `scflyspec.f`.
Without the control file `xrnspect.inp`, it behaves exactly like the original
`scflyspec` (trn mode).

The SCFLY population code itself is not included. Use your own SCFLY build,
but run it with the atomic data in `data/atomic.inp.29` (see "Important" below).

## Contents

```
scflyspec_xrn_cu/
├── README.md
├── src/
│   ├── scflyspec_xrn.f      modified scflyspec (single file; includes starkw)
│   ├── ilvcom.inc spect.inc atmdhs.inc   same as the standard SCFLY scflyspec
│   ├── xrncom.inc           new common blocks for xrn mode
│   └── Makefile
├── data/
│   ├── atomic.inp.29        SCFLY atomic data for Cu with the FLYCHK level structure (n <= 10)
│   ├── xrn.29               FLYSPEC line list for Cu
│   ├── flychk_levels.29     FLYCHK level list that defines the level indices in xrn.29
│   └── phistuf              Scofield photoionization fits (bound-free)
└── example/
    ├── 1_scfly/             SCFLY run: Cu, Te = 30 eV, Ne = 1e20 cm^-3, steady state
    ├── 2_spectrum/          scflyspec_xrn run on the step-1 populations, 5-300 eV
    ├── expected/            reference outputs of both steps and a check figure
    └── plot_spectrum.py     plots your result against the expected one
```

## Important: run SCFLY with `data/atomic.inp.29`

`xrn.29` refers to the energy levels of the FLYCHK level structure
(screened-hydrogenic superconfigurations up to n = 10).
`scflyspec_xrn` can only attach the xrn lines to the populations if the SCFLY
population file (`xout`) was produced with this level structure.

- Copy or link `data/atomic.inp.29` into the SCFLY run directory.
- Rerun SCFLY to produce `xout`.
- In the SCFLY runfile, use `isos 1 29 10`. Levels with principal quantum number
  above the third argument are dropped when `atomic.inp.29` is read, which would
  change the level indices.
- The populations you write into `xout` (for example converted from another
  model) must follow the level list in that `xout` file.
- Keep the level section of `xout` unchanged: `scflyspec_xrn` reads the level
  energies, statistical weights and shell occupations from it.

## Build (Linux, gfortran)

```bash
cd src
make            # builds ./scflyspec_xrn
make debug      # optional: bounds-checked build ./scflyspec_xrn_debug
```

## Example

```bash
cd example
./1_scfly/run.sh /path/to/your/scfly    # writes 1_scfly/xout (about 1 s)
./2_spectrum/run.sh                     # writes 2_spectrum/sp001xout etc. (about 2 s)
python3 plot_spectrum.py                # writes spectrum_check.png
```

Expected results:

- Step 1: `zb.xout` gives Zbar = 10.18. A FLYCHK steady-state run at the same
  conditions gives 10.12.
- Step 2: `spectrum.log` reports `xrn lines loaded: 26578  skipped: 0`.
  Lines are found for ions with 16 to 23 bound electrons.
- Compare `2_spectrum/sp001xout` with `expected/sp001xout`.
  `expected/spectrum_check.png` also shows the FLYCHK + FLYSPEC reference spectrum
  for the same conditions (`expected/flychk_flyspec_te30_ne1e20.dat`).
  The two models agree within 1 % in the main 3p-3d band (50-120 eV).
  The remaining differences elsewhere come from the different populations of the
  two codes, not from the line data.

## Input files for scflyspec_xrn

All input files are read from the working directory.

`runspect`, same format as the original scflyspec:

```
xout            population file (SCFLY xout, or a FLYCHK output file)
1 1 1           first time step, last time step, step interval
5. 300.         photon energy range [eV]
0.              plasma size [cm]; <= 0 uses the size in the file (minimum 1e-6 cm)
0.              Gaussian FWHM [eV] added to every line
0.              Lorentzian width added to every line
```

`xrnspect.inp`, which switches on xrn mode:

```
xrn.29             line 1: line list; 'none' = original trn mode
flychk_levels.29   line 2: FLYCHK level list for the xrn indices, or 'same'
1                  line 3: Stark widths (1 = on, 0 = off)
1                  line 4: line profile (1 = FLYSPEC, 0 = original scflyspec)
1                  line 5: bound-free (1 = FLYSPEC with phistuf, 0 = original scflyspec)
```

Lines 3-5 are optional and default to 1.

- Line 2: each FLYCHK level in `flychk_levels.29` is matched to the level in the
  population file with the same shell occupations (n = 1..10) and active shell.
  Use `same` only if the population file is itself a FLYCHK output file.
- Line 4, profile 1: as in FLYSPEC, each Voigt profile is cut at 25 * max(a, 1)
  widths and normalized to unit area on the energy grid. Profile 0 sums the full
  analytic Voigt wings over the whole grid.
- Line 5, bound-free 1: Scofield fits from `phistuf` for each ionized shell,
  with Kramers cross sections where no fit exists.

`phistuf` must also be in the working directory for bound-free option 1.

## Output files (time step NNN, population file name `xout`)

| file | content |
|---|---|
| `spNNNxout` | E [eV], intensity, blackbody limit, total emissivity, bound-bound, bound-free, free-free emissivity, then bound-bound emissivity per ion (ions listed in the `#t` header line) |
| `opNNNxout` | E [eV], optical depth, then the bound-bound, bound-free and free-free opacities, and the bound-bound opacity per ion |
| `bbNNNxout` | line list: ion, energy, flux, emissivity, optical depth, A value, Gaussian width [eV], Lorentzian width, upper/lower population, upper/lower level, lower/upper orbital |
| `bfNNNxout` | bound-free transitions: `s` = Scofield, `k` = Kramers |

Emissivities use the same units as the original scflyspec.

## How the xrn lines are computed

The line physics follows FLYSPEC (`readtrn`, `getintrn`, `mkgamma`).

- **Populations.** Each line uses the population of the whole superconfiguration.
  The A values in `xrn.29` are already weighted by the statistical weight of the
  sub-configuration.
- **Emissivity and opacity.** Emissivity = (h nu / 4 pi) P_u A.
  Opacity = 0.0265 P_l f (1 - stimulated emission).
- **Non-LTE correction.** If the population ratio of the two levels is close to
  Boltzmann (FLYSPEC `fnlte > 0.9`), the upper population is rescaled to the
  xrn line energy.
- **Delta n = 0 lines** (lower and upper level are the same superconfiguration)
  use a two-level collisional-radiative partition.
- **Gaussian width.** sqrt(Doppler^2 + (0.53 Stark)^2) + max(det, wix, E/2000).
- **Lorentzian width.** Radiative and autoionization widths from the population
  file, plus electron-impact excitation and ionization widths.
- **Ion selection.** Ions whose strongest line is above 1e-6 of the strongest
  line are kept, at most 22 ions.

## Validation

- **Against FLYSPEC.** With the same FLYCHK populations (Cu, 11 time steps,
  Te = 10-50 eV, Ne = 1e22-1e18 cm^-3) and the same `xrn.29`, every line in the
  FLYSPEC line list was reproduced. Emissivities and widths were identical to
  print precision. Band-integrated bound-bound emissivity agreed within 0.3 %
  (5-300 eV) for all time steps. The total spectrum agreed within 0.5 % for the
  time steps where FLYSPEC used the correct density for continuum lowering.
  FLYSPEC's `integral` mode uses the last time step's density there, which
  shifts its own bound-free edges at the other time steps.
- **trn mode.** Without `xrnspect.inp`, the outputs for an SCFLY Cu run with the
  `trn.29II` files are byte-identical to the original scflyspec.
- **This package.** The example was rebuilt and rerun from a clean copy.
  All outputs are byte-identical to `example/expected/`.

## Notes and limitations

- **Level structure.** In `data/atomic.inp.29`, ions with 1-26 bound electrons
  (Cu IV and higher charge states) have exactly the FLYCHK level structure.
  Cu III, II and I (27-29 bound electrons) have additional levels. All FLYCHK
  levels of these ions are still found by occupation, so no xrn line is lost.
  The additional SCFLY levels simply have no xrn lines. This package is intended
  for Zbar of about 3.5 and above.
- **Statistical weights.** For 12 K-shell-hole levels of Cu II (28 bound
  electrons), FLYCHK and SCFLY give different statistical weights for the same
  shell occupations. These levels are not populated in thermal plasmas.
- **Resolution.** The xrn lines are averaged over superconfigurations
  (sub-shell to sub-shell transitions). For detailed K-alpha satellite structure
  of low charge states, use the SCFLY `trn.29II` files (trn mode) instead.
- **Continuum lowering.** As in the original scflyspec, it uses Zbar of the
  previous time step. FLYSPEC uses the current one.
- **Cosmetic.** The Lorentzian FWHM value printed in the `sp`/`op` header lines
  comes from an uninitialized variable in the original `genspec`. It does not
  enter the calculation.

## Data provenance

| file | source |
|---|---|
| `atomic.inp.29` | `scfly-atomicData/FLYCHK_input_files/atomic.inp.29` |
| `xrn.29`, `phistuf` | FLYCHK/FLYSPEC data distribution (`xrn.tar`, `spec.tgz`) |
| `flychk_levels.29` | level section (`enot`/`elev` lines) of a FLYCHK Cu run, version of 7 Aug 2018, with screened-hydrogenic levels for all ions |
