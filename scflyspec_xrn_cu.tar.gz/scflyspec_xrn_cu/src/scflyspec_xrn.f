
      program scspect
c     computes spectrum using Mau Chen's jjatom subroutines 
c     and SCFLY Non-LTE population distributions
c     version 10.2 -  2016 October 27 for correction to IPD at 2 temperature cases to fix bound-bound emissivity
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      common /phiscof/ cphi(8,10,100),xphi(10,49,100)
      common/unit/ir,iw,iwa,iwr,iwp,iwc,iwpc
      common /lattice/rlattice,zbar0,ene0,ievolve
      common /bandstr/band(10),fwhml

      character*50 nametime
      character*55 filnam
      logical around

      fwhm=0.d0  ! fwhm of Gaussian width
      fwhml=0.d0 ! fwhm of Lorentzian width
      do i=1, 10
         band(i)=0.d0
      enddo
      inquire(file='runspect',exist=around)
      if(.not.around)then
         print *,'input file -runspect- is not around: stop'
         stop
      else
         sizem=0.
         idel=1
         fwhm=0.d0
         fwhml=0.d0
         open(1,file='runspect')
         read(1,'(a50)')nametime
         read(1,*)itmin, itmax, idel
         read(1,*,end=10)emin,emax
         read(1,*,end=10)sizem
         read(1,*,end=10)fwhm
         read(1,*,end=10)fwhml
         do ii=1,10
            iband=0
            btmp=0.d0
            read(1,*,iostat=ios,end=10) iband, btmp
            if(ios.ne.0) goto 10
            if(iband.ge.1.and.iband.le.10) band(iband)=btmp
         enddo
 10      close(1)
      endif

      inquire(file=nametime,exist=around)
      if(.not.around)then
         print *, 'output file not available', nametime
         stop
      endif

      open(unit=10,file=nametime,status='old')
      call subfile
      close(10)

      call xrninit


      itmax=min(numtimes,itmax)

      do it=itmin,itmax,idel
         itimes=it
         tev=tevm(1,itimes)
         time=timein(itimes)
         if(sizem.le.0.)then
            size=max(sizein(itimes),1.e-6)
         else
            size=sizem
         endif
         ene=densin(itimes)
         zelse=zelsein(itimes)
         zbar=zbarin(itimes)
         tiev=tievin(itimes)
         trev=trevin(itimes)
         totpop=totpin(itimes)         

         if(itimes.gt.1)then
            zbar0=zbarin(itimes-1)
            ene0=densin(itimes-1)
         else
            zbar0=zbarin(itimes)
            ene0=densin(itimes)
         endif

c     zero out the density for IPD states

         do k=1, iion
            debyek=debye(k)
            do i=1, naatot(k)
               ii=ncont(i,k)
               eip=eipz(k)+evfn(ii,k-1)-evfn(i,k)-debyek
               if(eip.le.0.d0) then
                  if(ppop(incnt(k)+i,itimes).gt.1.d-70) 
     &             print *, "check IPD",k,i,ii,
     &                 eip, ppop(incnt(k)+i,itimes)
                  ppop(incnt(k)+i,itimes)=0.d0
               endif
            enddo
         enddo


         write(*,'(/,"At time step: ",i3,"  Te=",0p,f11.4,
     &        " Ne=",1p,e12.4)')it,tev,ene

c     select bound-free transitions based on FLYSPEC

         call checkbf


         call gettran

         write(filnam,'("bb",i3.3,a50)')itimes,nametime
         open(20, file=filnam)
         write(20,'("v10.2-Widths: Gaussian, Lorentzian",2f12.3)')
     &        fwhm,fwhml
         write(20,'("Band:",10f10.3)') (band(i),i=1,10)
         write(20,'("Iso Energy[eV] Flux Emissivity   Tau    Avalue ",
     &   "WidGau[eV] WidLor[eV]PopUpLvl PopLowLvl UpLvl LowLvl ",
     &   "LowOrb UpOrb E_diff")')

         call readtran
         close(20)

         print *,'generating photon energy grid'
         tev=tevm(1,itimes)
         call genfrq

         write(filnam,'("bf",i3.3,a50)')itimes,nametime
         open(21, file=filnam)
         write(21,'("Key Iso IonPot[eV] " 
     &   "Emissivity Opacity PhotoCX ",
     &   "NumElec PopUpLvl PopLowLvl UpLvl LowLvl ElecOrb")')

         write(filnam,'("op",i3.3,a50)')itimes,nametime
         open(34, file=filnam)
         write(filnam,'("sp",i3.3,a50)')itimes,nametime
         open(35, file=filnam)
         print *,'generating spectra'

         tev=tevm(1,itimes)
         call genspec
         close(34)
         close(35)
         close(21)

      enddo

      stop
      end
c*********************************
      subroutine setfreq
      implicit real*8 (a-h,o-z)
c____ This routine reads in the data from the file connected to unit 1
      include 'ilvcom.inc'
      include 'spect.inc'
      parameter(mxfreq=20000)

      tx=tiev
      cwd= 4.6337e-5 *sqrt(tx/(2.*iion))
      dfreq=cwd*(emin+emax)/3.d0
      jtotal=int((emax-emin)/dfreq)+1
      if(jtotal.gt.mxfreq)then
         jtotal=mxfreq
         dfreq=(emax-emin)/(jtotal-1)
      endif
      e(1)=emin
      do ii=2,jtotal
         e(ii)=e(ii-1)+dfreq
      enddo
      return
      end


      subroutine genfrq
      implicit double precision(a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      parameter(nfrqff=200)
      parameter(nntmp=500000,nntmp2=1000000)
      dimension eitemp(nntmp2),etmp(2*nntmp)
      dimension febf(10)
      dimension pop(maxpop)

      parameter(mxbf=200000)
      common /transf/ntrf(maxion),ipsh(mxbf,maxion),
     &     npsh(mxbf,maxion)
      common /rtransf/
     &     epsh(mxbf,maxion),gpl(mxbf,maxion),gpu(mxbf,maxion),
     &     ppl(mxbf,maxion),ppu(mxbf,maxion)


      data febf/0.995,0.997,0.999,1.001,1.002,
     &     1.003,1.004,1.005,1.009,1.010/

      dimension etx(linmax),ietx(linmax)
      dimension ftx(linmax),iftx(linmax)
      dimension emxion(0:maxion),emiion(0:maxion)

c   VOIGT
      common /freq_i/ nfreq
      common /freq_r/ evw8(12)

      dimension ev(25), ev5(11),evw5(5)
      data nfreq/ 25 /
      data evw8 /0.15, 0.3, 0.50, 0.8, 1.10,
     *     1.500, 2.00, 3.00, 4.00, 5.00, 8.00, 15.00 /
      data evw5 /0.15, 0.4, 1., 1.5, 2.0/

c___determine ratio of lorentz to doppler widths:  a=wi/wd
c      wd = sqrt(2.0*boltz*tiev*11604.5/(2.0*atomzin*amass))
c     *     *(ranghi+ranglo)*0.5/speed
c      wd = 4.6337e-5 *sqrt(tiev/atom_mass_number)*energy(eV)


      atomz=float(iion)
      cwd= 4.6337e-5 *sqrt(tiev/(2.*atomz))

      nfreqh = nfreq/2+1
      nfrqm1 = nfreqh-1

      ev(nfreqh) = 0.00
      do j=1,nfrqm1
         ev(nfreqh+j) =  evw8(j)
         ev(nfreqh-j) = -evw8(j)
      enddo
      do i=1,nfreq
         ev(i) = -ev(i)
      enddo
      
      nfreq2=11
      ev5(6)=0.d0
      do j=1, 5
         ev5(6+j)=evw5(j)
         ev5(6-j)=-evw5(j)
      enddo
      do j=1, nfreq2
         ev5(j)=-ev5(j)
      enddo

      do j=1,numpop
         pop(j) = ppop(j,itimes)
      enddo

      emxtot=0.d0
      emitot=0.d0
      sff = 0.d0
      do iso=1, isomax
         emxion(iso)=0.d0
         emiion(iso)=0.d0
         k=indion(iso)
         if(k.ne.0) then
            do itr=1, ntri(k)
               if(eml(itr,k).gt.emxion(iso))then
                  emxion(iso)=max(emxion(iso),eml(itr,k))
                  phi0=2.333325e-15/wdt(itr,k)*voigt(0.d0,avt(itr,k))
                  emiion(iso)=eml(itr,k)*phi0
               endif
            enddo
         endif
         emxtot=max(emxtot,emxion(iso))
         emitot=max(emitot,emiion(iso))
         indn = incnt(iso)
         do i=1,naatot(iso)
            sff = sff+pop(indn+i)*(atomz-float(iso))**2
         enddo
      enddo


      epsf2=0.d0
      do it=1, int(xtem(itimes))
         tex=tevm(it,itimes)
         cone = 5.05e-41*ene*sff/sqrt(tex)
         epsf2=epsf2+
     &        cone*exp(-emax/tex)*fnem(it,itimes)
      enddo
      flumin=epsf2/emitot   ! ratio to the maximum line emissivity



      tvtmax=0.
      tvtmin=1.d30
      twmin=(emax-emin)*0.0001
      npts=0

      do 10 iso=isomin,isomax
         k=indion(iso)
         if(k.eq.0) goto 10
 1       ntmp=0
         avtmax=0.
         avtmin=1.d30
         dwmin=max(cwd*emin*0.1,0.0002d0)
         if(fwhm.gt.0.d0) dwmin=max(fwmm*0.1,dwmin)
c     first find out the strongest 10 lines from each ion
         do itr=1,ntri(k)
            ftx(itr)=eml(itr,k)
            iftx(itr)=itr
         enddo
         nptf=ntri(k)
         call sortrn(nptf,ftx,iftx) ! index inversion
c     rearrange the energy in the ascending order
         do itrx=1,ntri(k)
            itr=iftx(itrx) ! original index 
            etx(itr)=ei(itr,k)
            ietx(itr)=itrx
         enddo
         nptx=ntri(k)
         call sortrn(nptx,etx,ietx) ! index inversion
         ntf=max(1,nptf-20)
         ntf2=max(1,nptf-100)
         do itrx=2,ntri(k)
            if(etx(itrx).le.etx(itrx-1)+0.0005)then  ! closely spaced transtions
               itrf=ietx(itrx)
               itmx=max(ietx(itrx),ietx(itrx-1)) ! stronger line
               if(itmx.ge.ntf)then
c               if(iso.eq.4) write(*,'(2f11.4,0p,2i8,1p,2e11.4)') 
c     &                 etx(itrx), etx(itrx-1), ietx(itrx), 
c     &                 ietx(itrx-1),ftx(ietx(itrx)),ftx(ietx(itrx-1))
                  ntf=max(1,ntf-1)
                  iftx(itrf)=0
               else if(itmx.ge.ntf2)then
c               if(iso.eq.4) write(*,'(2f11.4,0p,2i8,1p,2e11.4)') 
c     &                 etx(itrx), etx(itrx-1), ietx(itrx), 
c     &                 ietx(itrx-1),ftx(ietx(itrx)),ftx(ietx(itrx-1))
                  ntf2=max(1,ntf2-1)
                  iftx(itrf)=0
               else
                  iftx(itrf)=0
               endif
            endif
         enddo
c     ignore closely spaced transitions
         nptx=1
         do 101 itrx=1,ntri(k)
            itr=iftx(itrx)  ! original transition index @ array ftx
            if(itr.eq.0) then
               goto 101         ! not participating in the grid selection
            endif
            euln=ei(itr,k)
            wd = wdt(itr,k)
            f  = max(avt(itr,k),1.0)
            phi0=2.333325e-15/wd*voigt(0.d0,avt(itr,k))
            emilx=eml(itr,k)*phi0
            epsff=epsf2*exp(-(euln-emax)/tex)
            if(itrx.ge.ntf)then   ! most strong 30 lines
               dwmin =min(dwmin,0.2*wd*f)
               avtmin=min(avtmin,avt(itr,k))
               avtmax=max(avtmax,avt(itr,k))
               do j=1,nfreq
                  ntmp=ntmp+1
                  etmp(ntmp)=euln-ev(j)*wd*f
               enddo
            else if(itrx.ge.ntf2)then  ! 100 lines
               dwmin =min(dwmin,0.2*wd*f)
               avtmin=min(avtmin,avt(itr,k))
               avtmax=max(avtmax,avt(itr,k))
               do j=1,nfreq2
                  ntmp=ntmp+1
                  etmp(ntmp)=euln-ev5(j)*wd*f
               enddo
            else if(emilx.gt.epsff*0.1) then
               euln=ei(itr,k)
               wd = wdt(itr,k)
               f  = max(avt(itr,k),1.0)
               do j=1,nfreq2
                  ntmp=ntmp+1
                  etmp(ntmp)=euln-ev5(j)*wd*f
               enddo
            else if(eml(itr,k)/emxtot.gt.flumin*1.d-2) then
               ntmp=ntmp+1
               etmp(ntmp)=euln
            endif
 101     continue


c     remove too closely lying points
         nptx=ntmp
         if(nptx.ge.1)then
            iflag=0
            call rdgrid(nptx,etmp,iflag)
            ntmp=nptx
         endif
         tvtmin=min(tvtmin,avtmin)
         tvtmax=max(tvtmax,avtmax)

         if(ntmp.gt.nntmp)then
            if(flumin.lt.1.e-2)then
               flumin=flumin*10.
               print *, 'flumin ', flumin, k, iso
               goto 1
            else
               iflag=2
               nptx=ntmp
               call rdgrid(nptx,etmp,iflag)
               if(nptx.gt.nntmp)then
                  print *, 'too many energy points in 1',nptx,k
                  print *, 'please reduce spectral range'
                  jflag=1
                  return
               else
                  ntmp=nptx
               endif
            endif
         endif

         twmin =min(twmin,dwmin)
         avtmin=tvtmin
         avtmax=tvtmax
         dwmin =twmin
         if(fwhm.gt.0.d0) dwmin=max(fwmm*0.1,dwmin)

         print *, 'generating', ntmp, ' points ', iso


         do ii=1, ntmp
            if(etmp(ii).gt.0.99*emin.and.etmp(ii).lt.1.01*emax)then 
               npts=npts+1
               eitemp(npts)=etmp(ii)
               if(npts.eq.nntmp2) then
                  iflag=2
                  call rdgrid(npts,eitemp,iflag)
                  if(npts.eq.nntmp2) then
                     print *, 'too many energy points 2',npts,k
                     iflag=3
                     npts0=npts
                     call rdgrid(npts0,eitemp,iflag)
                     if(npts0.eq.nntmp2) then
                        print *, 'please reduce spectral range'
                        jflag=1
                        return
                     else
                        npts=npts0
                     endif
                  endif
               endif
            endif
         enddo

 10   continue


c     add free-free
      dloghv=log(emax/emin)/(nfrqff-1)
      hvlog=log(emin)-dloghv
      do i=1, nfrqff
         hvlog=hvlog+dloghv
         eitemp(npts+i)=exp(hvlog)
      enddo
      ntmp=npts+nfrqff

c     add bound-free

      do k=isomin,isomax
         debyek=debye(k)
         do 11 i=1, nbound(k)
            eip=eipz(k)-evfn(i,k)-debyek
            if(eip.gt.emin.and.eip.lt.emax) then
               do ii=1,10
                  ntmp=ntmp+1
                  eitemp(ntmp)=eip*febf(ii)
               enddo
            endif
 11      continue
         do it=1, ntrf(k)
            eip=epsh(it,k)-debyek
            if(eip.gt.emin.and.eip.lt.emax) then
               do ii=1,10,2 
                  eipg=eip*febf(ii)
                  if(eipg.gt.emin.and.eipg.lt.emax) then
                     ntmp=ntmp+1
                     eitemp(ntmp)=eipg
                  endif
               enddo
            endif
         enddo
      enddo

      print *, 'generating total ', ntmp, ' points'

      iflag=0

      if(ntmp.ge.1)call rdgrid(ntmp,eitemp,iflag)

      if(ntmp.le.jbig)then
         jtotal=ntmp
         do ii=1, ntmp
            e(ii)=eitemp(ii)
         enddo
      else
         print *,'too many enenrgy points'
         print *,'please reduce the spectral range'
         stop
      endif

      write(*,'("nphot, amin, amax = ",i7,1p,2e10.2)') 
     &     jtotal, tvtmin,tvtmax

      return
      end
      
      subroutine rdgrid(ntmp,etmp,iflag)
      implicit double precision(a-h,o-z)
      dimension etmp(ntmp)
      common /voit/ avtmin,avtmax, cwd, dwmin


c     sorting in ascending order
      call sort(ntmp,etmp)

c      eul=0.5*(etmp(1)+etmp(ntmp))
c      sum=0.d0
c      do ii=2, ntmp
c         xx=(etmp(ii)-eul)/cwd/eul
c         dx=(etmp(ii)-etmp(ii-1))/cwd/eul/1.77245d0
c         sum=sum+voigt(xx,avtmax)*dx
c      enddo
c
c     eliminating duplicate or too-closely spaced points
      eratio=1.e-6
      dw=max(dwmin,eratio*etmp(1))
      if(iflag.eq.0)dw=max(1.e-3,dw)
      if(iflag.eq.2)dw=max(1.e-2,dw)
      if(iflag.eq.3)dw=max(1.e-1,dw)

      i=1
      do 20 n=2, ntmp
         if(etmp(n) .gt. etmp(i)+dw)then
            i=i+1
            etmp(i)=etmp(n)
         endif
 20   continue

c      write(*,'("grid reduced",2i8,1p,e12.2)')i,ntmp,dw 

      ntmp=i
      return
      end

      subroutine sortrn( npts,xin,ixin)
      implicit double precision (a-h,o-z)


c ... puts the elements of "xin" into ascending order

      dimension xin(npts),ixin(npts)
      logical flag
      jt1=npts-1
      do 100 i=1, jt1
         etmp=xin(i)
         jmin=i
         ip1=i+1
         do 200 j=ip1, npts
            if (xin(j).gt.etmp) goto 200
            etmp=xin(j)
            jmin=j
 200     continue
         xin(jmin)=xin(i)
         xin(i)=etmp
         isave=ixin(jmin)
         ixin(jmin)=ixin(i)
         ixin(i)=isave
 100  continue
      return
      end


c*********************************
      subroutine subfile
      implicit real*8 (a-h,o-z)
c____ This routine reads in the data from the file connected to unit 1

      include 'ilvcom.inc'
      common /lattice/rlattice,zbar0,ene0,ievolve

      character*3  evolve
      character*8  adu(100)
      dimension noc1(25),noc2(25)

c__read the calculation parameters from the input file.

c      print *, ' reading headers'

      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,1155,err=200) iion,adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,1160,err=200) evolve !evolve
      read (10,'(a8)',err=200) adu(100)!history
      read (10,'(a8)',err=200) adu(100)!time

      ievolve=0
      if(evolve .eq. 'td ')ievolve=1

 1155 format (49x,i2,3x,a8)
 1160 format (49x,a3)
 1164 format (49x,i10,3x,i10)
 1165 format (49x,1p,e9.2)
c
      read (10,'(a8)',err=200) adu(100)
      read (10,1164  ,err=200) isomin,isomax
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)

      rlattice=0.d0
      read (10,1165 ,err=200) rlattice
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)
      read (10,'(a8)',err=200) adu(100)

      atomz=float(iion)
      dopc = sqrt(atomz)*4.357e-20

      k=0
      naatot(k)=1
      nbound(k)=1
      nauto(k)=0
      gfn(1,k)=1.d0
      evfn(1,k)=0.d0
      sqq(1,k)=0.d0

      do 160 k=1,iion

c__      get the level mix information for the data in the file.

         read(10,'(12i10)',err=200)naatot(k),nbound(k),nauto(k),incnt(k)
     1                            ,iamst
         nlv = naatot(k)
         nbn = nbound(k)
         nau = nauto(k)
         ntotal    = naatot(k)
c

c         print *, ' reading atomic data'
c____  skip the ev, ip, and g information and get the level names.

         read(10,'(4x,2i5,1x,2f16.5)')iso,nprimm,eipz(k)
         if(iso.ne.k) print *,'iso .ne. k'
         do j=1, ntotal
            read(10,101)iso,ii,namlev(j,k),evfn(j,k),gfn(j,k),sqq(j,k),
     &      (nocel(j,k,iob),iob=1,nprim),morb(j,k)
         enddo
 101     format(4x,2i4,1x,a8,1x,f14.4,1x,1p,e16.8,1x,e12.4,
     &        0p,1x,10i3,1x,i4)

c____  get the rates for the relevant bound states.

         do 161 i=2,ntotal
            im1 = i-1
            read(10,'(1p,10e12.5)',err=200) (aratefn(i,j,k),j=1,im1)
  161    continue
	 read(10,'(1p,10e12.5)',err=200) (rtgam(j,k),j=1,ntotal)
  160 continue

c___  set up ionization transitions for bound-free spectra

       do iz=1, iion
          do i=1, naatot(iz)
             nnn=nprim
             if(morb(i,iz).le.10.and.morb(i,iz).gt.nprim)nnn=morb(i,iz)
             do ip=1,nnn
                noc1(ip)=nocel(i,iz,ip)
             enddo
             do j=1, naatot(iz-1)
                do ip=1,nnn
                   noc2(ip)=nocel(j,iz-1,ip)
                enddo
                ietrn(i,j,iz)=0
                call getlnpqs(noc1,noc2,n1,n2,nnn)
                if(morb(i,iz).gt.nprim)then
                   if(morb(j,iz-1).eq.morb(i,iz))then
                      if(n1.gt.0.and.n2.eq.0) then
                         ietrn(i,j,iz)=noc1(n1)
                      endif
                   else
                      if(n1.eq.0.and.n2.eq.0) then
                         ietrn(i,j,iz)=1
                      endif
                   endif
                else
                   if(morb(i,iz).le.nprim)then                   
                      if(n1.gt.0.and.n2.eq.0) then
                         ietrn(i,j,iz)=noc1(n1) 
                      endif
                   endif
                endif
                if(ietrn(i,j,iz).ne.0.and.morb(i,iz).eq.n1)then
                   ncont(i,iz)=j
                endif
             enddo
          enddo
       enddo

c__ now read all the population information

      ntimes = 0

  170 continue

      read(10,'(3i10)',end=173,err=200) iolow,iohigh,numpopo
      if(iolow.le.0) goto 173
      numpop=numpopo
      incnt(0)=numpop-1

      if (iolow .gt. maxtimes) then
         go to 173
      endif
      if (iohigh .gt. maxtimes) then
         ionow = maxtimes
      else
         ionow = iohigh
      endif
      
c____ Now read the level populations

      do 171 i=1,numpop
         read(10,'(10x,(10e12.5))',err=200) (ppop(i,j),j=iolow,ionow)
 171  continue


      read(10,'(a8)',err=200) adu(100)
      read(10,'(a8)',err=200) adu(100)
      read(10,'(10x,(10e12.5))',err=200) (zelsein(j),j=iolow,ionow)
      read(10,'(a8)',err=200) adu(100)
      read(10,'(a8)',err=200) adu(100)
      read(10,'(a8)',err=200) adu(100)
         
      read(10,'(10x,(10e12.5))',err=200) (densin(j),j=iolow,ionow)
      read(10,'(10x,(10e12.5))',err=200) (totpin(j),j=iolow,ionow)
      read(10,'(10x,(10e12.5))',err=200) (zbarin(j),j=iolow,ionow)
      read(10,'(10x,(10e12.5))',err=200) (sizein(j),j=iolow,ionow)


      read(10,'(10x,(10e12.5))',err=200) (trevin(j),j=iolow,ionow)
      read(10,'(10x,(10e12.5))',err=200) (tievin(j),j=iolow,ionow)
      
      read(10,'(10x,(10e12.5))',err=200) (tevin(j),j=iolow,ionow)
      read(10,'(10x,(10e12.5))',err=200) (timein(j),j=iolow,ionow)
      read(10,'(10x,(10e12.5))',err=200) (xtem(j),j=iolow,ionow)

      nmx=1
      do j=iolow,ionow
         nmx=max(nmx,int(xtem(j)))
      enddo
      do ii=1,nmx
         read(10,'(10x,(10e12.5))',err=200)(tevm(ii,j),j=iolow,ionow)
      enddo
      do ii=1,nmx
         read(10,'(10x,(10e12.5))',err=200)(fnem(ii,j),j=iolow,ionow)
      enddo
         
      if (ionow .eq. maxtimes) then
         go to 173
      endif

      go to 170

  173 continue

      numtimes = ionow

      return

 201  format(46x,3x,i2)
 202  format(46x,3x,a4,2x,a20)
 203  format(46x,3x,a8,1pe9.2)
 204  format(46x,3x,a8,1pe9.2)
 205  format(46x,1x,a9,1p,2e9.2)
 206  format(46x,3x,a4,1x,a10)
 207  format(46x,3x,0p,3f8.2)
 208  format(46x,3x,a20,1x,a20)
 209  format(46x,3x,a3)
 210  format(46x,3x,a20,1x,2a3)
 211  format(46x,3x,1p3e9.2)
 212  format(46x,3x,a20)
 213  format(46x,3x,i10,3x,i10)
 214  format(46x,3x,i10,3x,i10)
 215  format(46x,3x,i10)
 216  format(46x,3x,i10)

c
c____ There is an error in reading

  200 continue

      write(*,*)' **** Error reading. Is it a file created by FLYCHK?'
      return
      end

c**********************************************************************
      subroutine readtran
      implicit double precision(a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      include 'atmdhs.inc'

      common /bandstr/band(10),fwhml

      dimension pop(maxpop)
      common /frnlte/tevhi,fnlte(nlvi,nlvi,maxion)
      common /etrn/emitx,emimx(nlvi,nlvi,maxion),konly(maxion),
     &     ionly(nlvi,maxion),itonly(nlvi,nlvi,maxion)

      logical ionly,konly,around
      character*200 msg
      character*10 dhsname

      dimension nrdx(26)
      common /phiscof/ cphi(8,10,100),xphi(10,49,100)

      parameter(mxbf=200000)
      common /transf/ntrf(maxion),ipsh(mxbf,maxion),
     &     npsh(mxbf,maxion)
      common /rtransf/
     &     epsh(mxbf,maxion),gpl(mxbf,maxion),gpu(mxbf,maxion),
     &     ppl(mxbf,maxion),ppu(mxbf,maxion)


      common /chekbf/epfly(nlvi,nlvi,maxion),
     &     ebfly(nlvi,nlvi,maxion),obfly(nlvi,nlvi,maxion)


      dimension gtev0(nlvi,0:mxion),ppmx(nlvi,0:mxion)
      dimension eipl(50000,nlvi),eipu(50000,nlvi)
      dimension nlevx(nlvi)

       character*3 let(49)
       data let/'1s ','2s ','2p-','2p+',
     &      '3s ','3p-','3p+','3d-','3d+',
     &      '4s ','4p-','4p+','4d-','4d+','4f-','4f+',
     &      '5s ','5p-','5p+','5d-','5d+','5f-','5f+','5g-','5g+',
     &      '6s ','6p-','6p+','6d-','6d+','6f-','6f+','6g-','6g+',
     &            '6h-','6h+',
     &      '7s ','7p-','7p+','7d-','7d+','7f-','7f+','7g-','7g+',
     &            '7h-','7h+','7i-','7i+'/
      include 'xrncom.inc'
c *******************************************************
      if(lxrn) then
         call readxrn
         return
      endif
c  set up population density
      totpop=totpin(itimes)
      do j=1,numpop
         pop(j) = ppop(j,itimes)
      enddo

c  set up initialization
      do ii=1, 8
         do ish=1,10
            do iso=isomin,isomax
               cphi(ii,ish,iso)=0.d0
            enddo
         enddo
      enddo
      do i=1,mxistg
         ntri(i)=0
      enddo
c  find ionizations stages with bb transition
      k=0
      do iso=isomin,isomax
         indion(iso)=0
         if(konly(iso))then
            k=k+1
            indion(iso)=k
            index(k)=iso
         endif
         ntrf(iso)=0
      enddo
      kmx=k

c  constant definition
      const=2.333325e-15
      cone=1.2749813d-13        !cone=hp*evtohz/(4.0*pi) 
      cwd= 4.6337e-5 *sqrt(tiev/(2.*iion))

      gtev(1,0)=1.d0
      eipu(1,1)=1.d0

      write(*,'("# of detailed transitions")')

c----  use effective temperature for population distribution within super-configuration
c      teffx for gtev and gtev0 calculations

      do 10 iso=isomin,isomax

         do k=1,naatot(iso)
            gtev0(k,iso)=0.d0
            gtev(k,iso)=0.d0
            ppmx(k,iso)=0.d0
            nlevx(k)=0
         enddo

c         write(dhsname,'("tr.",i2.2,i2.2)')iion,iso
         write(dhsname,'("trn.",i2.2,i2.2)')iion,iso
         inquire(file=dhsname,exist=around)
         if(.not.around) goto 10
         open(10,file=dhsname)
         read(10,*)nlv,nsc,npi,nbf,nbb
c   read level information 
c   read to compute gtev and find the maximum population per ion
         tev=tevm(1,itimes)
         debyek=debye(iso)
         do in=1,nlv
            read(10,902)k,i,ii,gl,el,eip,(nrdx(iob),iob=1,26)
            if(pop(incnt(iso)+k).gt.0.d0)then
               if(i.eq.1) erd0=el
               if(eip-debyek.gt.0.d0.and.abs(el-erd0)/tev.lt.30.) then
                  de=el-erd0
                  teffx=fTeff(tev,ene,trev,de)
                  ppmx(k,iso)=max(ppmx(k,iso),gl*exp(-de/teffx))
                  gtev0(k,iso)=gtev0(k,iso)+gl*exp(-de/teffx)
               endif
            endif
         enddo
         rewind 10
         close(10)

c   find the maximum population densities
         pmaxx=0.d0
         do k=1,naatot(iso)
            if(gtev0(k,iso).gt.0.d0) then
               ppmx(k,iso)=ppmx(k,iso)/gtev0(k,iso)
               pmaxx=max(pmaxx,ppmx(k,iso))
            endif
         enddo

c     remove the high lying states
c     and read again the information 
c     increase lines


         open(10,file=dhsname)
         read(10,*)nlv,nsc,npi,nbf,nbb
         ncount0=0
         ncount=0
         cutoff=0.0
         tev=tevm(1,itimes)
         do in=1,nlv
            read(10,902)k,i,ii,gl,el,eip,(nrdx(iob),iob=1,26)
            if(pop(incnt(iso)+k).gt.0.d0)then
               if(i.eq.1) erd0=el
               eipl(i,k)=eip
               nlevx(k)=i
c     set up cut-off levels  
               frac=0.d0
               ncount0=ncount0+1
               de=el-erd0
               teffx=fTeff(tev,ene,trev,de)
               if(abs(de/teffx).lt.30..and.gtev0(k,iso).gt.0.d0) then
                  frac=gl*exp(-de/teffx)/gtev0(k,iso)
               endif
               if(abs(de/teffx).lt.30) then
                  gtev(k,iso)=gtev(k,iso)+gl*exp(-de/teffx)
                  ncount=ncount+1
               endif
            endif
         enddo


c   read scofield bf cross-section
         do in=1,nsc
            read(10,901)k,ish,(cphi(ip,ish,k),ip=1,8)
         enddo
c   read wilson bf cross-section
         do in=1,npi
            read(10,901)k,ish,(xphi(ip,ish,k),ip=1,10)
         enddo
c   set up bf transition information
         tev=tevm(1,itimes)
         do 11 in=1,nbf
            read(10,903)k,i,ki,ii,n1,n2,eip,gl,gu,el,eu
            eipdby=eip-debyek
            if(xphi(5,n1,iso)*xphi(6,n1,iso).le.0.d0) goto 11

            if(pop(incnt(iso)+k)*pop(incnt(iso-1)+ki).le.0.d0) goto 11
            if(pop(incnt(iso)+k)/totpop.lt.1.d-15.and.
     &           pop(incnt(iso-1)+ki)/totpop.lt.1.d-15) goto 11
            if(ebfly(k,ki,iso).lt.1.d-8.and.
     &           obfly(k,ki,iso).lt.1.d-8) goto 11

c           remove states with IPD
c            if(eipl(i,k).le.0.d0)goto 11
c            if(eipu(ii,ki).le.0.d0)goto 11  ! add continuum opacity

            if(gtev(ki,iso-1).le.1.d-30) goto 11 ! remove for IPD states
            if(gtev(k,iso).le.1.d-30)print *, 'warning gtev',k,iso

            teffl=fTeff(tev,ene,trev,el)
            if(abs(el/teffl).gt.20.) goto 11

            if(eipdby.gt.emax) goto 11      ! continuum edge > emax

           if(10.*eipdby.le.emin )goto 11   ! too far from the continuum edge

            teffu=fTeff(tev,ene,trev,eu)
            if(abs(eu/teffu).le.20.) then
               pu=pop(incnt(iso-1)+ki)*gu/gtev(ki,iso-1)*exp(-eu/teffu)
            else
               pu=0.d0
           endif
            pl=pop(incnt(iso)+k)*gl/gtev(k,iso)*exp(-el/teffl)

            ntrf(iso)=ntrf(iso)+1
            ipsh(ntrf(iso),iso)=n1
            npsh(ntrf(iso),iso)=n2
            epsh(ntrf(iso),iso)=eip
            gpl(ntrf(iso),iso)=gl
            gpu(ntrf(iso),iso)=gu
            ppl(ntrf(iso),iso)=pl
            ppu(ntrf(iso),iso)=pu

 11      continue
c   set up bb transition information
         k=indion(iso)
         if(k.eq.0) goto 21
         do 12 in=1,nbb
            read(10,904)il,iu,ilj,iuj,n1,n2,euln,el,eu,
     &           gl,gu,flu,avalue,det
            if(ilj.eq.0.or.iuj.eq.0) goto 12

            eulnx=euln+5.*cwd*euln+det+fwhm !add gaussian width
            eulnm=euln-5.*cwd*euln+det+fwhm !add gaussian width

            if(eulnx.lt.emin.or.eulnm.gt.emax)goto 12

            if(pop(incnt(iso)+il)*pop(incnt(iso)+iu).le.0.d0) goto 12

c           remove states with IPD and filter defined above
c           lower level population
c           fix 2015/11/24
c           if(gtev(il,iso).lt.1.d-28.or.abs(el/tev).gt.30.)goto 12  
c           fix 2016/10/24
c           abs(el/tev) condition is harsh for low temperature cases
c           Ti K-alpha spectrum shows only one peak.
c           Fix it as follows

            if(gtev(il,iso).lt.1.d-28)goto 12

            teffl=fTeff(tev,ene,trev,el)
            teffu=fTeff(tev,ene,trev,eu)

            if(iuj.ne.1.and.abs(el/teffl).gt.30.)goto 12  

c           remove weak emission and weak opacity
            pl=pop(incnt(iso)+il)*gl*exp(-el/teffl)/gtev(il,iso)

c            if(gtev(iu,iso).gt.1.d-28)then
            if(gtev(iu,iso).gt.1.d-28.and.abs(eu/teffu).lt.30.)then
               pu=pop(incnt(iso)+iu)*gu/gtev(iu,iso)*exp(-eu/teffu)
            else
               pu=0.d0
            endif

            if(pl/totpop.lt.1.d-18.and.pu/totpop.lt.1.d-18) then
               goto 12
            endif



            npqup=morb(iu,iso)      !principal quantum number of upper level
            wdg=cwd*euln+det + fwhm !add gaussian width
            wdg=wdg + band(npqup)   ! add band bradening with gaussian profile
            wdl=(rtgam(iu,iso)+rtgam(il,iso)+fwhml)/2.417969d14 ! lorentzian
            avg=wdg/wdl/12.57d0
            if(euln.gt.emax.or.euln.lt.emin)then
               vg0=voigt(0.d0,avg)
               xx=(emin-euln)/wdg
               phl=voigt(xx,avg)/vg0
               xx=(emax-euln)/wdg
               phu=voigt(xx,avg)/vg0
               phx=max(phl,phu)
c               if(phx.lt.1.e-5) goto 12
            else
               phx=1.d0
            endif
            ntri(k)=ntri(k)+1
            itr=ntri(k)
            ei(itr,k)=euln
            fln(itr,k)=flu
            ffnlte=fnlte(iu,il,iso)
c            if(ffnlte.gt.0.9)then
c               pu=ffnlte*pl*gfn(iu,iso)/gfn(il,iso)*exp(-euln/tevhi)
c               flu=avalue*gfn(iu,iso)/gfn(il,iso)/euln**2/4.34327d7
c            endif
            opl(itr,k)=0.0265*pl*flu
            if(euln/tevhi.lt.70.)then
               opl(itr,k)=opl(itr,k)*(1.0-ffnlte*exp(-euln/tevhi))
            endif
            if(opl(itr,k).lt.0.d0)then
               opl(itr,k)=0.0265*pl*flu*(1.0-exp(-euln/tevhi))
            endif
            eml(itr,k)=cone*pu*avalue*euln
            wdt(itr,k)=wdg
            avt(itr,k)=wdl/(wdt(itr,k)*12.57)
            phi0=const/wdt(itr,k)*voigt(0.d0,avt(itr,k))
            srcfn=eml(itr,k)/opl(itr,k)
            taufn=opl(itr,k)*phi0*size
            if(taufn.lt.0.001)then
               flx=eml(itr,k)*phi0*size
            else
               flx=srcfn*(1.-exp(-taufn))
            endif
            if(pu/totpop.gt.1e-12.or.pl/totpop.gt.1.e-8) then
            write(20,'(i2,1x,f10.3,1p,8e10.2,2x,2i4,2x,2(1x,a3),
     &           0p,f10.3,1p,4e11.2)')iso,euln,flx,eml(itr,k),taufn,
     &           avalue,wdt(itr,k),wdl,pu,pl,iu,il,let(n1),let(n2),
     &           evfn(iu,iso)-evfn(il,iso)-euln,
     &           gl*exp(-el/tev),gu*exp(-eu/tev)
            endif

 12      continue
 21      close(10)
         nbbb=0
         if(k.ne.0)nbbb=ntri(k)
         if(nbbb.gt.linmax) then
            print *,'too many lines nbb=',nbbab,'> linmax',linmax 
         endif
         write(*,'("ion: ",i2,"   bb= ",i6,"  bf= ",i6, " --- ", 
     &        i6, " of ", i6, " levels used")')
     &        iso,nbbb,ntrf(iso),ncount, ncount0
         do k=1,naatot(iso)
            do i=1,nlevx(k)
               eipu(i,k)=eipl(i,k)
            enddo
         enddo

 10   continue


 901  format(1x,2i3,1p,10e12.4)
 902  format(1x,i3,i6,i6,1p,e12.4,0p,2f15.4,i2,1x,3i2,
     &     1x,5i2,1x,6i2,i3,1x,6i2,3i3,1x,i4)
 903  format(1x,i3,i5,i3,i6,i3,i3,1p,10e12.4)
 904  format(1x,2i4,2i6,1x,2i3,1x,f15.4,1p,10e12.4)
      return
      end


c*****************************************************************

      function fTeff(Te,ne,Tr,dE)
      implicit none
      real*8 fTeff,Te,ne,Tr,dE,px,pdx,cx,cdx,Ar,chi,b
      real*8 alpha, ry, hbar
      data Ry/13.605 698 1 d0/, hbar/6.582 119 d-16/
      alpha=1d0/137.0359895d0
      !calculate rates (all with f=1 and cdx/pdx absent g0/g1)

      if(dE.le.0.01*Te) then
         fTeff=Te
         return
      endif

	Ar=(alpha**3/Ry/hbar*dE**2) !estimate Ar with f=1

	pdx=Ar
	px=0d0	
	if(Tr.gt.0.) then 
	 if(dE/Tr.lt.700.) px=Ar/(dexp(dE/Tr)-1d0)
	 pdx=pdx+px
	end if
	b=dE/Te
        if(b.ge.700.) b=700.
	chi=dlog(1.d0+(0.562+1.4*b)/(b+1.4*b**2)) !within 3% of exp(-b)Ei(-b)
	cx=0d0
	if(b.lt.700.)cx=ne*1.58e-5*dexp(-b)/dE/Te**.5*(0.15+0.28*chi)
	cdx=dexp(b)*cx

	!In steady-state, X1/X0=(cx+px)/(cdx+pdx)
	!calculate effective temperature from Boltzmann relation X1/X0=g1/g0*exp[-dE/Teff]
	fTeff=-dE/dlog((cx+px)/(cdx+pdx))

        if(fTeff.lt.1.0d0)fTeff=0.2*Te
c        if(abs(fTeff-Te).gt.0.01) print *, fTeff, dE, ne, Te

c        fTeff=Te
        return
        end

c*****************************************************************

      subroutine gettran
      implicit double precision (a-h,o-z)

      include 'ilvcom.inc'
      include 'spect.inc'
      include 'atmdhs.inc'
      common /frnlte/tevhi,fnlte(nlvi,nlvi,maxion)
      common /etrn/emitx,emimx(nlvi,nlvi,maxion),konly(maxion),
     &     ionly(nlvi,maxion),itonly(nlvi,nlvi,maxion)



      logical ionly,konly

      totpop=totpin(itimes)

      do k=isomin,isomax
         konly(k)=.false.
         do iu=1,naatot(k)
            ionly(iu,k)=.false.
         enddo
      enddo

      emitx=0.d0
      nmx=int(xtem(itimes))
      tevhi=tevm(nmx,itimes)

      do 20 k=isomin,isomax
         do 30 iu=2,naatot(k)
            pu = ppop(incnt(k)+iu,itimes)
            if(pu.lt.1.d-70) goto 30
            do 40 il=1,iu-1
               itonly(iu,il,k)=0
               emimx(iu,il,k)=0.d0
               fnlte(iu,il,k)=0.d0
               pl = ppop(incnt(k)+il,itimes)
               if(pl.lt.1.d-70) goto 40
               if (aratefn(iu,il,k) .gt. 0.00) then
                  etran = evfn(iu,k)-evfn(il,k)
                  if(pl/totpop.gt.1.e-30)then
                     if(etran/tevhi.lt.70.)then
                        fnlte(iu,il,k)=(pu/pl)/
     &                    (gfn(iu,k)/gfn(il,k)*exp(-etran/tevhi))
                     endif
                     if(etran.ge.0.95*emin.and.etran.le.1.05*emax)
     &                    then
                        emiln=pu*aratefn(iu,il,k)*etran
                        emimx(iu,il,k)=emiln
                        emitx=max(emitx,emiln)
                     endif
                  endif
               endif
 40         continue
 30      continue
 20   continue
      

      
      do k=isomin,isomax
         do iu=2,naatot(k)
            do il=1,iu-1
               if(emimx(iu,il,k).gt.emitx*1.e-15)then
                  konly(k)=.true.
                  ionly(iu,k)=.true.
                  ionly(il,k)=.true.
                  itonly(iu,il,k)=1
                  etran = evfn(iu,k)-evfn(il,k)
               endif
            enddo
         enddo
      enddo
      return
      end


      double precision function binom(nvac,nwt)
      implicit double precision (a-h,o-z)

      if (nvac.eq.nwt.or.nwt.eq.0) then
         binom=1.d0
         return
      else if(nvac.gt.nwt) then
         denom=1.d0
         do ii=1, nwt
            denom=denom*ii
         enddo
         dnumer=nvac*1.d0
         do ii=nvac-1, nvac+1-nwt,-1
            dnumer=dnumer*ii
         enddo
         binom=dnumer/denom
      else
         print *, nvac, nwt, 'check'
      endif
      return
      end

c*********************************************************************
      subroutine genspec
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      include 'xrncom.inc'

c___create the emissivities and opacitis
c
c
       do 52 j=1, jtotal
          eff(j)=0.d0
          ebf(j)=0.d0
          ebb(j)=0.d0
          off(j)=0.d0
          obf(j)=0.d0
          obb(j)=0.d0
 52    continue

c
c___create bound-free and free-free emissivity and opacity.
c
       print *, 'bound-bound spectra'

       call specbb

       print *, 'free-free spectra'

       call specff

       print *, 'bound-free spectra'

       if(lxrn.and.ibfx.eq.1) then
          call specbfx
       else
          call specbf
       endif


c
c___create total emissivity and opacity.
c___add bound-bound contributions
c
       ymin=1.d-70
       do 7 j=1, jtotal
          o = e(j)
          spectra(j)=0.d0
          ebf(j)=max(ebf(j),ymin)
          obf(j)=max(obf(j),ymin)
          eff(j)=max(eff(j),ymin)
          off(j)=max(off(j),ymin)
          eps(j)=eff(j)+ebf(j)
          opa(j)=off(j)+obf(j)
          do 8 i=isomin,isomax
             k=indion(i)
             if(k.eq.0) goto 8
             se(j,k)=max(se(j,k),ymin)
             sk(j,k)=max(sk(j,k),ymin)
             ebb(j)=ebb(j)+se(j,k)
             obb(j)=obb(j)+sk(j,k)
             eps(j)=eps(j)+se(j,k)
             opa(j)=opa(j)+sk(j,k)
 8        continue
 7     continue


       wfhm=max(fwhm,fwhml)
       write(34,
     & '("#t ",i3,f11.3,1p,4e10.2," tau obb obf off sk(i)=
     &      ",26i5)')
     &      itimes,tev,ene,size,time,wfhm,(index(iss),iss=1,kmx)
       write(35,
     & '("#t ",i3,f11.3,1p,4e10.2," tot plf emi bb bf ff ",
     &   " se(i)="   26i5)')
     &      itimes,tev,ene,size,time,wfhm,(index(iss),iss=1,kmx)

       do 16 j=1,jtotal
          y = opa(j)*size
          if (y .lt. 0.001) then
             s1 =eps(j)*size*(1.-y/2.)
          else
             s1 = eps(j)/opa(j)*(1-exp(-y))
          endif
          if(e(j)/tev.le.1.d2)then
             s2=2.0838e-4 * e(j)**3*exp(-e(j)/tev)/(1.-exp(-e(j)/tev))
          else
             s2=1.d-70
          endif
          spectra(j) = s1
          
          write(34,'(f12.5,1pe13.5,31e10.2)')e(j),max(ymin,opa(j)*size),
     &         obb(j),obf(j),off(j),(sk(j,k),k=1,kmx)
          write(35,'(f12.5,1pe13.5,31e10.2)')e(j),max(ymin,spectra(j)),
     &         max(ymin,s2),eps(j),ebb(j),ebf(j),eff(j),
     &         (se(j,k),k=1,kmx)
 16    continue

       write(34,'(" ")')
       write(35,'(" ")')

       return
c
c   e r r o r   m e s s a g e
c
 3000  write (ioo,3010)
 3010  format(' *** (Makespec) no data')
       return
c
 3020  write(ioo,3030)
 3030  format(' *** (Makespec) too many points in total spectrum array')

       return
c
       end

      subroutine sort ( npts,xin )
      implicit double precision (a-h,o-z)

c ... puts the elements of "xin" into ascending order

      dimension xin(npts)
      logical flag
      jt1=npts-1
      do 100 i=1, jt1
         etmp=xin(i)
         jmin=i
         ip1=i+1
         do 200 j=ip1, npts
            if (xin(j).gt.etmp) goto 200
            etmp=xin(j)
            jmin=j
 200     continue
         xin(jmin)=xin(i)
         xin(i)=etmp
 100  continue
      return
      end


      subroutine getnpqs(iz1,j1,iz2,j2,n1,n2)
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
c ... compare shell occupations to identify principal quantum numbers
c ... for a potential transition

c ---------------------------------------------------------------------
      n1 = 0
      n2 = 0
      do 100 ip = 1,nprim
         ndp = nocel(j1,iz1,ip) - nocel(j2,iz2,ip)
         if (ndp.eq.1) then
            if (n1.eq.0) then
               n1 = ip
            else
               n1 = -1
            endif
         elseif (ndp.eq.-1) then
            if (n2.eq.0) then
               n2 = ip
            else
               n2 = -1
            endif
         elseif (ndp.ne.0) then
            n1 = -1
         endif
  100 continue
      return
      end
c***************************************************************************
      function voigt (vv,a)
      implicit double precision (a-h,o-z)
c ... this subroutine computes the Voigt function "h" as a function
c     of "a" and "v".  See Mihalas, "Stellar Atmospheres", 1978, for
c     definitions and details.
      dimension atab(11),vtab(11),htable(11,11)
      dimension table1(21),table2(11)

      data atab /  1.00E-01,1.58E-01,2.51E-01,3.98E-01,6.31E-01,
     2    1.00E+00,1.58E+00,2.51E+00,3.98E+00,6.31E+00,1.00E+01 /
      data vtab /  0.00E+00,5.00E-01,1.00E+00,1.50E+00,2.00E+00,
     2    2.50E+00,3.00E+00,3.50E+00,4.00E+00,4.50E+00,5.00E+00 /
      data htable /
     2  8.96E-01,8.44E-01,7.69E-01,6.72E-01,5.54E-01,4.28E-01,3.08E-01,
     3 2.10E-01,1.38E-01,8.83E-02,5.61E-02, 7.18E-01,6.85E-01,6.38E-01,
     4 5.72E-01,4.89E-01,3.91E-01,2.92E-01,2.04E-01,1.36E-01,8.78E-02,
     5 5.60E-02, 3.73E-01,3.74E-01,3.72E-01,3.63E-01,3.43E-01,3.05E-01,
     6 2.50E-01,1.88E-01,1.30E-01,8.63E-02,5.56E-02, 1.34E-01,1.48E-01,
     7 1.66E-01,1.87E-01,2.05E-01,2.12E-01,1.98E-01,1.65E-01,1.22E-01,
     8 8.39E-02,5.49E-02, 4.02E-02,5.18E-02,6.85E-02,9.07E-02,1.17E-01,
     9 1.40E-01,1.51E-01,1.40E-01,1.12E-01,8.07E-02,5.40E-02, 1.47E-02,
     1 2.19E-02,3.28E-02,4.86E-02,6.97E-02,9.38E-02,1.13E-01,1.17E-01,
     2 1.02E-01,7.69E-02,5.29E-02, 7.94E-03,1.25E-02,1.95E-02,3.01E-02,
     3 4.55E-02,6.53E-02,8.53E-02,9.64E-02,9.11E-02,7.27E-02,5.16E-02,
     4  5.34E-03,8.44E-03,1.33E-02,2.08E-02,3.21E-02,4.77E-02,6.58E-02,
     5 7.97E-02,8.09E-02,6.83E-02,5.01E-02, 3.92E-03,6.21E-03,9.81E-03,
     6 1.54E-02,2.40E-02,3.63E-02,5.18E-02,6.62E-02,7.16E-02,6.39E-02,
     7 4.85E-02, 3.02E-03,4.79E-03,7.57E-03,1.19E-02,1.86E-02,2.85E-02,
     8 4.17E-02,5.55E-02,6.33E-02,5.94E-02,4.69E-02, 2.41E-03,3.81E-03,
     9 6.03E-03,9.52E-03,1.49E-02,2.30E-02,3.42E-02,4.69E-02,5.59E-02,
     1 5.51E-02,4.51E-02 /

c ... "table1" and "table2" are used to compute Dawson's integral 
c     (which is used to compute the Voigt function for small "a"):
c                               _v
c       D.I.  =  exp(-v**2) * _/ dt exp(t**2)
c                            0
c
      data table1 / .00000, .09933, .19475, .28263, .35994,
     2      .42443, .47476, .51050, .53210, .54072, .53807,
     3      .52620, .50727, .48339, .45650, .42824, .39993,
     4      .37255, .34677, .32297, .30134 /
      data table2 / .50000, .50650, .51358, .52142, .53037,
     2      .54079, .55265, .56547, .57852, .59110, .60268 /

      data sqrtpi / 1.7725 /

      data xxxmax / 20. /


c ********************************************************************
c
c                           begin execution
c
c ********************************************************************

      v = abs( vv )

      if ( a .eq. 0. ) then

c ...    Doppler profile

         voigt = exp( -v*v )

      else if ( v.ge.5. .or. a.ge.10. ) then

c ...    Lorentzian profile in limit of large a,v

         voigt = a / sqrtpi / ( a*a + v*v )

      else if ( a.le.0.1 ) then

c ...    use Dawson's integral (see Mihalas) for small "a"

         if ( v .le. 2. ) then
            x = v
            ix = min ( 1. + x / 0.1 , xxxmax )
            f = x/0.1 - (ix-1)
            y = (1.-f) * table1(ix) + f * table1(ix+1)
            dawson = y
         else
            x = 1. / (v*v)
            ix = 1 + x / 0.025
            f = x/0.025 - (ix-1)
            y = (1.-f) * table2(ix) + f * table2(ix+1)
            dawson = y / v
         endif

         voigt = exp( -v*v ) + 2.*a/sqrtpi *
     &           ( 2.*v*dawson - 1. )

      else

c ...    use a table lookup

         aalog = log10( a )
         ia = aalog/0.2 + 6
         iv = v/0.5 + 1
         fa = aalog/0.2 - (ia-6)
         fv = v/0.5 - (iv-1)
         g1 = (1.-fa)*htable(ia,iv) + fa*htable(ia+1,iv)
         g2 = (1.-fa)*htable(ia,iv+1) + fa*htable(ia+1,iv+1)
         voigt = (1.-fv)*g1 + fv*g2

      endif
      return
      end
c--------------------------------------------------------
      subroutine specbb
      implicit double precision(a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      include 'xrncom.inc'
      external voigt

      cwd= 4.6337e-5 *sqrt(tiev/(2.*iion))
      evtohz=2.417969e+14
c      const=1.d0/evtohz/1.77245d0
      const=2.333325e-15

      do 100 iso=isomin,isomax
         k=indion(iso)
         if(k.eq.0)goto 100
         do jj=1, jtotal
            sk(jj,k)=0.d0
            se(jj,k)=0.d0
         enddo
         do 101 it=1, ntri(k)
            if(eml(it,k).le.0.d0)goto 101
            euln=ei(it,k)
            wd = wdt(it,k)
            cphi0=const/wd
            avoit0=avt(it,k)
            f     =max(avoit0,1.)
c            xx=(e(1)-euln)/wd
c            xy=(e(jtotal)-euln)/wd
c            sum=cphi0*voigt(xx,avoit0)*(e(2)-e(1))/2.
c     &       +cphi0*voigt(xy,avoit0)*(e(jtotal)-e(jtotal-1))/2.
c            do 102 jj=2, jtotal-1
c               xx=(e(jj)-euln)/wd ! in eV
c               sum=sum+
c     &              cphi0*voigt(xx,avoit0)*(e(jj+1)-e(jj-1))/2.*evtohz
c 102        continue
            if(lxrn.and.iprof.eq.1) then
c              FLYSPEC genski: profile cut at 25*max(a,1) widths and
c              normalized to unit area on the energy grid
               sum=0.d0
               do jj=2, jtotal-1
                  xx=(e(jj)-euln)/wd
                  if(abs(xx).le.50.*f) sum=sum+cphi0*voigt(xx,avoit0)
     &                 *(e(jj+1)-e(jj-1))/2.*evtohz
               enddo
               if(sum.le.0.d0) goto 101
               do jj=1, jtotal
                  xx=(e(jj)-euln)/wd
                  if(abs(xx).le.25.*f) then
                     phix=cphi0*voigt(xx,avoit0)/sum
                     sk(jj,k)=sk(jj,k)+opl(it,k)*phix
                     se(jj,k)=se(jj,k)+eml(it,k)*phix
                  endif
               enddo
               goto 101
            endif
            do 103 jj=1, jtotal
               xx=(e(jj)-euln)/wd ! in eV
               phix=cphi0*voigt(xx,avoit0)
               sk(jj,k)=sk(jj,k)+opl(it,k)*phix
               se(jj,k)=se(jj,k)+eml(it,k)*phix
 103        continue
 101     continue
 100  continue
      return
      end

      subroutine specff
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      dimension pop(maxpop)

      sum=0.d0
      do 111 j=1,numpop
         pop(j) = ppop(j,itimes)
         sum=sum+pop(j)
 111  continue


      sff = 0.00
      atomz=float(iion)
      do 50 k=0,isomax
         indn = incnt(k)
         do 51 i=1,naatot(k)
            sff = sff+pop(indn+i)*(atomz-float(k))**2
 51      continue
 50   continue

c     compute free-free Gaunt factor from a simple fit to the
c     results of Karzas and Latter (Ap. J. Suppl. 6, 167 (1961))
      totpop=totpin(itimes)
      gam2lg=log10(13.6058*sff/totpop/tev)
      gbrem=1.+0.44*exp(-0.25*(gam2lg+0.25)**2)

      cono=ene*sff*2.42d-37*gbrem
      cone=ene*sff*5.05d-41*gbrem
      do 52 j=1, jtotal
         o = e(j)
         cteo=0.d0
         ctee=0.d0
         do it=1, int(xtem(itimes))
            tex=tevm(it,itimes)
            if(o/tex.le.1.d2) then
               cteo=cteo+fnem(it,itimes)*(1.0-exp(-o/tex))/sqrt(tex)
               ctee=ctee+fnem(it,itimes)*exp(-o/tex)/sqrt(tex)
            endif
         enddo
         off(j)=cono*cteo/o**3
         eff(j)=cone*ctee
 52   continue
      
      return
      end

      subroutine specbf
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      dimension pop(maxpop)

      common /dhsocc/nobm,noc1(100),noc2(100)
      common /phistuff/ cp0,cp1,cp2,cp3,xn,cep,cem
      common /phiscof/ cphi(8,10,100),xphi(10,49,100)

      parameter(mxbf=200000)
      common /transf/ntrf(maxion),ipsh(mxbf,maxion),
     &     npsh(mxbf,maxion)
      common /rtransf/
     &     epsh(mxbf,maxion),gpl(mxbf,maxion),gpu(mxbf,maxion),
     &     ppl(mxbf,maxion),ppu(mxbf,maxion)

      common /lattice/rlattice,zbar0,ene0,ievolve
      data pi /3.1415926/

       character*3 let(36)
       data let/'1s ','2s ','2p-','2p+',
     &      '3s ','3p-','3p+','3d-','3d+',
     &      '4s ','4p-','4p+','4d-','4d+','4f-','4f+',
     &      '5s ','5p-','5p+','5d-','5d+','5f-','5f+','5g-','5g+',
     &      '6s ','6p-','6p+','6d-','6d+','6f-','6f+','6g-','6g+',
     &            '6h-','6h+'/

       external phicx
c---------------------------------------------------------------
c
c___create bound-free emissivity and opacity.
c   BF transitions of outer electron from the bound states
c     emissivity = (2hv^3/c^2) * n' exp(-hv/kT) c.x(v)
c     c.x (v)= 4.12e26 * I^2.5 /zeff / v^3 * pn
c     rlte = (1.66d-22*ene)*(gl/gu)/tev**1.5 * exp(I/kT)
c     n' = rlte * pu 

      do j=1,numpop
         pop(j) = ppop(j,itimes)
      enddo
      nmx=int(xtem(itimes))
      
c     BF transitions 
      nobm=nprim
      totpop=totpin(itimes)

      do 64 k=isomin,isomax
         tev=tevm(1,itimes)
         debyek=debye(k)
         do 65 i=1, naatot(k)
            pl = pop(incnt(k)+i)
            if (pl/totpop .le. 1.d-30) go to 65
            if(gtev(i,k).gt.0.d0) goto 65
c --------- Hydrogenic Cross-sections --------------
            do ip=1,nobm
               noc1(ip)=nocel(i,k,ip)
            enddo
            gl = gfn(i,k)
            do 66 iu=1, naatot(k-1)
               do ip=1,nprim
                  noc2(ip)=nocel(iu,k-1,ip)
               enddo
               call getiob(n1,n2)
               if(n1.gt.0.and.n2.eq.0)then
                  gu = gfn(iu,k-1)
                  pu = pop(incnt(k-1)+iu)
                  eip=eipz(k)+evfn(iu,k-1)-evfn(i,k)-debyek
                  if(eip.le.1.d-30)goto 66
                  xn =cphi(5,n1,k)
                  if(xn.gt.0.d0) then
                     cp0=cphi(1,n1,k)
                     cp1=cphi(2,n1,k)
                     cp2=cphi(3,n1,k)
                     cp3=cphi(4,n1,k)
                     cep=cphi(6,n1,k)
                     cem=cphi(7,n1,k)
c     
c     Scofield Photoionization Cross-sections - Original
c                     conphi = 1.d-18*(13.606/cep)*xn
c                     oxx=conphi*pl
c
c                     do ii=1,nmx
c                        tev=tevm(ii,itimes)
c                        frc=fnem(ii,itimes)
c                        olt=(1.66d-22*ene)*(gl/gu)/tev**1.5
c                        exx=2.08d-4*olt*conphi*pu
c                        phix=phicx(0.d0)
c                        if(eip.ge.emin.and.eip.le.emax)
c     &                    write(21,'("s",i4,1x,f10.3,1p,6e10.2,2x,2i4,
c     &                    1x,a3)')k,eip,exx*phix*eip**3,oxx*phix,
c     &                    phix*conphi,xn,pu,pl,iu,i,let(n1)
c                        do 68 j=1, jtotal
c                           o = e(j)
c                           if(o.gt.eip) then
c                              xx=log(o/cep)
c                              obf(j)=obf(j)+frc*oxx*phicx(xx)
c                              if(abs(eip-o)/tev.lt.70.)then
c                                 ebf(j)=ebf(j)+frc*exx*phicx(xx)*
c     &                                o**3*exp((eip-o)/tev)
c                                 obf(j)=obf(j)-frc*oxx*phicx(xx)*
c     &                                olt*(pu/pl)*exp((eip-o)/tev)
c                              endif
c                           endif
c 68                     continue
c                     enddo
c
c----------------------------------------------------------------------
c     Scofield Photoionization Cross-sections 2012-08-09 (Orlando)
                     enemi=min(eip,cep)
                     conphi = 1.d-18*(13.606/enemi)*xn
                     oxx=conphi*pl

                     do ii=1,nmx
                        tev=tevm(ii,itimes)
                        frc=fnem(ii,itimes)
                        olt=(1.66d-22*ene)*(gl/gu)/tev**1.5
                        exx=2.08d-4*olt*conphi*pu
                        phix=phicx(0.d0)
                        if(eip.ge.emin.and.eip.le.emax)
     &                    write(21,'("s",i4,1x,f10.3,1p,6e10.2,2x,2i4,
     &                    1x,a3)')k,eip,exx*phix*eip**3,oxx*phix,
     &                    phix*conphi,xn,pu,pl,iu,i,let(n1)
                        do 68 j=1, jtotal
                           o = e(j)
                           if(o.gt.eip) then
                              xx=log(o/enemi)
                              obf(j)=obf(j)+frc*oxx*phicx(xx)
                              if(abs(eip-o)/tev.lt.70.)then
                                 ebf(j)=ebf(j)+frc*exx*phicx(xx)*
     &                                o**3*exp((eip-o)/tev)
                                 obf(j)=obf(j)-frc*oxx*phicx(xx)*
     &                                olt*(pu/pl)*exp((eip-o)/tev)
                              endif
                           endif
 68                     continue
                     enddo
c----------------------------------------------------------------------
                  else
                     pn=noc1(n1)
                     zeff=sqq(i,k)
                     conphi = 2.91437d-17*eip**2.5/zeff*pn ! kramer c.x. in eV
                     oxx=conphi*pl
                     do ii=1,nmx
                        tev=tevm(ii,itimes)
                        frc=fnem(ii,itimes)
                        olt=(1.66d-22*ene)*(gl/gu)/tev**1.5
                        exx=2.08d-4*olt*conphi*pu
                        phix=conphi/eip**3
                        if(eip.ge.emin.and.eip.le.emax)
     &                    write(21,'("k",i4,1x,f10.3,1p,6e10.2,2x,2i4,
     &                    1x,a3)')k,eip,exx,oxx/eip**3,phix,xn,pu,pl,
     &                       iu,i,let(n1)
                        do 67 j=1, jtotal
                           o = e(j)
                           if(o.gt.eip) then
                              obf(j)=obf(j)+frc*oxx/o**3
                              if(abs(eip-o)/tev.lt.70.)then
                                 ebf(j)=ebf(j)+frc*exx*exp((eip-o)/tev)
                                 obf(j)=obf(j)-frc*oxx/o**3*
     &                             olt*(pu/pl)*exp((eip-o)/tev)
                              endif
                           endif
 67                     continue
                     enddo
                  endif
               endif
 66         continue
 65      continue
c --------- Configuration-average Cross-sections --------------
         do 72 it=1, ntrf(k)
            pl=ppl(it,k)
            pu=ppu(it,k)
            n1=ipsh(it,k)
            eip=epsh(it,k)-debyek
            gl=gpl(it,k)
            gu=gpu(it,k)
            xn = npsh(it,k)
            cp0=xphi(1,n1,k)
            cp1=xphi(2,n1,k)
            cp2=xphi(3,n1,k)
            cp3=xphi(4,n1,k)
            cep=xphi(6,n1,k)
            cem=xphi(7,n1,k)
            cmx=xphi(8,n1,k)
            con=xphi(9,n1,k)
            pow=xphi(10,n1,k)
            conphi = 1.d-18*(13.606/cep)*xn
            oxx=conphi*pl
            do ii=1,nmx
               tev=tevm(ii,itimes)
               frc=fnem(ii,itimes)
               olt=(1.66d-22*ene)*(gl/gu)/tev**1.5
               exx=2.08d-4*olt*conphi*pu
               phix=phicx(0.d0)
               write(21,'("m",i4,1x,f10.3,1p,6e10.2,2x,8x,1x,a3)')
     &              k,eip,exx*phix*eip**3,oxx*phix,phix*conphi,xn,
     &              pu,pl,let(n1)   

               do 73 j=1, jtotal
                  o = e(j)
                  if(o.gt.eip) then
                     if(o.le.cmx)then
                        xx=log(o/cep)
                        if(xx.lt.0.d0) xx=0.d0
                        obf(j)=obf(j)+frc*oxx*phicx(xx)
                        if(abs(eip-o)/tev.lt.70.)then
                           ebf(j)=ebf(j)+frc*exx*phicx(xx)*
     &                          o**3*exp((eip-o)/tev)
                           obf(j)=obf(j)-frc*oxx*phicx(xx)*
     &                          olt*(pu/pl)*exp((eip-o)/tev)
                        endif
                     else
                        if(pow.gt.0.d0)then
                           phix=con/o**pow
                           obf(j)=obf(j)+frc*pl*phix
                           if(abs(eip-o)/tev.lt.70.)then
                              ebf(j)=ebf(j)+frc*2.08d-4*olt*pu*phix*
     &                             o**3*exp((eip-o)/tev)
                              obf(j)=obf(j)-frc*pl*phix*
     &                             olt*(pu/pl)*exp((eip-o)/tev)
                           endif
                        endif
                     endif
                  endif
 73            continue

            enddo
 72      continue
c------------------------------------------------------------------
 64   continue

      return
      end
      
      function debye(iz)
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      common /lattice/rlattice,zbar0,ene0,ievolve
      data pi /3.1415926/
      data echa /4.803242d-10/
      data evergg /1.602d-12/
 
      zz=iion-iz+1.

      if(ievolve.eq.1)then
         edens = ene0
      else
         edens = ene
      endif

      ztot=zbar0+zelse

      rdebye = 743.3913*sqrt(tev/(edens*(1.+ztot)))

      if(rlattice.gt.1.d-30)then
         rib = (0.75/(pi*(edens+totpop)))**(1./3.)
         dencri=(0.75/pi)*(tev*evergg/(iion*echa)**2)**(3.)
         debye0=(echa**2)/(rdebye*evergg)
         debye1=(echa**2)/(rib*evergg)

         if(edens.le.dencri) then
            debye = zz*debye0
         else
            debye = zz*rlattice*debye1
         endif

      else
         rib = (0.75*zz/(pi*edens))**(1./3.)
         rfz = rdebye/rib
         debye0 = 2.16e-7/rib*((1.+rfz**3)**(2./3.)-rfz**2)
         debye1 = 1.45e-07/sqrt((rib/1.5)**2+rdebye**2+rlattice**2)
         debye = zz*min(debye1,debye0)
      endif

      return
      end



      subroutine getiob(n1,n2)
      implicit double precision(a-h,o-z)
      common /dhsocc/nobm,noc1(100),noc2(100)

      n1 = 0
      n2 = 0
      do 100 ip = 1,nobm
         ndp = noc1(ip) - noc2(ip)
         if (ndp.eq.1) then
            if (n1.eq.0) then
               n1 = ip
            else
               n1 = -1
            endif
         elseif (ndp.eq.-1) then
            if (n2.eq.0) then
               n2 = ip
            else
               n2 = -1
            endif
         elseif (ndp.ne.0) then
            n1 = -1
         endif
  100 continue
      return
      end

      subroutine getlnpqs(noclev,nocion,n1,n2,nprim)
      implicit real*8 (a-h,o-z)
      dimension noclev(nprim),nocion(nprim)
c ... compare shell occupations to identify principal quantum numbers
c ... for a potential transition

c ---------------------------------------------------------------------
      n1 = 0
      n2 = 0
      do 100 ip = 1,nprim
         ndp = noclev(ip)-nocion(ip)
         if (ndp.eq.1) then
            if (n1.eq.0) then
               n1 = ip
            else
               n1 = -1
            endif
         elseif (ndp.eq.-1) then
            if (n2.eq.0) then
               n2 = ip
            else
               n2 = -1
            endif
         elseif (ndp.ne.0) then
            n1 = -1
         endif
  100 continue
      return
      end

      subroutine mkgamma(iz)
c
c___ this calculates the collisional excitation or de-excitation
c___ from level i to level j of an ion (with iz electrons)
c___ in the average-atom model.
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      dimension cxgam(nlvi)

c Dick's suggestion... ignore collisional rates
      do iu=1,naatot(iz)
         gu=gfn(iu,iz)
         ii=ncont(iu,iz)
         eip=eipz(iz)+evfn(ii,iz-1)-evfn(iu,iz)-debye(iz)
         ebt = eip/tev
         cxgam(iu)=0.d0
         if(ebt.lt.70.) then
            exebt=exp(-ebt)
            cxgam(iu)=ene*2.97e-6/(sqrt(tev)*eip)*ex1(ebt,exebt)
         endif
         do 100 il=1,iu-1
            gl=gfn(il,iz)
            eji = evfn(iu,iz)-evfn(il,iz)
            fij = aratefn(iu,il,iz)*gu/gl/eji**2/4.34327d7
            if(fij.le.0.d0.or.eji.le.0.d0) goto 100
            ebt = eji/tev
            if(ebt.lt.70.) then            
               gaunt = 0.15 + 0.28*exp1x(ebt)
               cxgam(il)=cxgam(il)+ 
     &              ene*1.578d-5/eji*fij*gaunt/sqrt(tev)*exp(-ebt)
               cxgam(iu)=cxgam(iu)+
     &              ene*1.578d-5/eji*fij*gaunt/sqrt(tev)*gl/gu
            endif
 100     continue
      enddo

c     check if rtgam > dE
      do iu=1,naatot(iz)
         ii=ncont(iu,iz)
         eip=eipz(iz)+evfn(ii,iz-1)-evfn(iu,iz)-debye(iz)
         if(eip.gt.0.d0)then
            dEhz = 2.* eip / morb(iu,iz)*evtohz
            cxgam(iu)=min(cxgam(iu),dEhz)
            rtgam(iu,iz)=rtgam(iu,iz)+cxgam(iu)
         endif
      enddo


      return
      end

      function exp1x(x)

c ... exp(x) times
c ... Rational approximation to 1st exponential integral (within 5.e-5)
c ... (ref. Abramowitz and Stegun, p. 231

      real*8 x,x0,x1,a0,a1,a2,a3,a4,a5,b1,b2,b3,b4,exp1x

      data x0,x1 / 1.d-4, 1.d0 /

      data a0,a1,a2,a3,a4,a5
     &     / -.57721566d0, .99999193d0,-.24991055d0,
     &        .05519968d0,-.00976004d0, .00107857d0 /

      data b1,b2,b3,b4 / 2.334733d0,0.250621d0,3.330657d0,1.681534d0 /

      if (x.lt.x0) then
         exp1x = (1.d0 + x) * (-log(x) + a0 + x*(a1 + x*a2))
      elseif (x.lt.x1) then
         exp1x = exp(x) *
     &           (-log(x) + a0 + x*(a1 + x*(a2+ x*(a3+ x*(a4 + x*a5)))))
      else
         exp1x = (b2 + x*(b1 + x)) / (b4 + x*(b3 + x)) / x
      endif

      return
      end

      function ex1(xt,expx)
      implicit real*8 (a-h,o-z)
      dimension e1data(334)
      data nexp1/334/, dexp1/.075/, deoff/.025/
      data (e1data(i),i=1,334)/
     & 3.137E+00,1.823E+00, 1.333E+00, 1.044E+00, 8.471E-01, 7.024E-01,
     & 5.913E-01,5.034E-01, 4.323E-01, 3.738E-01, 3.250E-01, 2.840E-01,
     & 2.492E-01,2.194E-01, 1.937E-01, 1.716E-01, 1.523E-01, 1.355E-01,
     & 1.207E-01,1.078E-01, 9.638E-02, 8.631E-02, 7.740E-02, 6.949E-02,
     & 6.246E-02,5.620E-02, 5.062E-02, 4.564E-02, 4.118E-02, 3.719E-02,
     & 3.361E-02,3.040E-02, 2.751E-02, 2.491E-02, 2.258E-02, 2.047E-02,
     & 1.857E-02,1.686E-02, 1.531E-02, 1.391E-02, 1.264E-02, 1.149E-02,
     & 1.046E-02,9.517E-03, 8.664E-03, 7.891E-03, 7.189E-03, 6.552E-03,
     & 5.974E-03,5.448E-03, 4.970E-03, 4.535E-03, 4.139E-03, 3.779E-03,
     & 3.452E-03,3.153E-03, 2.881E-03, 2.633E-03, 2.407E-03, 2.201E-03,
     & 2.013E-03,1.841E-03, 1.684E-03, 1.541E-03, 1.411E-03, 1.291E-03,
     & 1.182E-03,1.083E-03, 9.919E-04, 9.086E-04, 8.325E-04, 7.629E-04,
     & 6.992E-04,6.409E-04, 5.876E-04, 5.388E-04, 4.941E-04, 4.532E-04,
     & 4.157E-04,3.814E-04, 3.499E-04, 3.211E-04, 2.947E-04, 2.705E-04,
     & 2.483E-04,2.279E-04, 2.093E-04, 1.922E-04, 1.765E-04, 1.621E-04,
     & 1.489E-04,1.368E-04, 1.257E-04, 1.155E-04, 1.061E-04, 9.752E-05,
     & 8.963E-05,8.239E-05, 7.573E-05, 6.962E-05, 6.401E-05, 5.886E-05,
     & 5.412E-05,4.977E-05, 4.578E-05, 4.210E-05, 3.873E-05, 3.563E-05,
     & 3.278E-05,3.015E-05, 2.775E-05, 2.553E-05, 2.349E-05, 2.162E-05,
     & 1.990E-05,1.832E-05, 1.686E-05, 1.552E-05, 1.429E-05, 1.315E-05,
     & 1.211E-05,1.115E-05, 1.027E-05, 9.454E-06, 8.706E-06, 8.018E-06,
     & 7.385E-06,6.802E-06, 6.265E-06, 5.771E-06, 5.316E-06, 4.897E-06,
     & 4.512E-06,4.157E-06, 3.830E-06, 3.529E-06, 3.252E-06, 2.997E-06,
     & 2.762E-06,2.545E-06, 2.346E-06, 2.162E-06, 1.993E-06, 1.837E-06,
     & 1.693E-06,1.561E-06, 1.439E-06, 1.326E-06, 1.223E-06, 1.127E-06,
     & 1.040E-06,9.585E-07, 8.838E-07, 8.150E-07, 7.515E-07, 6.931E-07,
     & 6.392E-07,5.895E-07, 5.436E-07, 5.014E-07, 4.625E-07, 4.266E-07,
     & 3.935E-07,3.630E-07, 3.348E-07, 3.089E-07, 2.849E-07, 2.629E-07,
     & 2.425E-07,2.238E-07, 2.065E-07, 1.905E-07, 1.758E-07, 1.622E-07,
     & 1.497E-07,1.381E-07, 1.274E-07, 1.176E-07, 1.085E-07, 1.002E-07,
     & 9.245E-08,8.532E-08, 7.875E-08, 7.268E-08, 6.709E-08, 6.193E-08,
     & 5.716E-08,5.276E-08, 4.871E-08, 4.496E-08, 4.151E-08, 3.832E-08,
     & 3.538E-08,3.266E-08, 3.015E-08, 2.784E-08, 2.570E-08, 2.373E-08,
     & 2.191E-08,2.023E-08, 1.868E-08, 1.725E-08, 1.593E-08, 1.471E-08,
     & 1.358E-08,1.255E-08, 1.159E-08, 1.070E-08, 9.881E-09, 9.126E-09,
     & 8.428E-09,7.784E-09, 7.190E-09, 6.640E-09, 6.133E-09, 5.665E-09,
     & 5.233E-09,4.834E-09, 4.465E-09, 4.124E-09, 3.810E-09, 3.519E-09,
     & 3.251E-09,3.003E-09, 2.775E-09, 2.563E-09, 2.368E-09, 2.188E-09,
     & 2.021E-09,1.867E-09, 1.725E-09, 1.594E-09, 1.473E-09, 1.361E-09,
     & 1.257E-09,1.162E-09, 1.074E-09, 9.920E-10, 9.167E-10, 8.471E-10,
     & 7.827E-10,7.233E-10, 6.684E-10, 6.177E-10, 5.708E-10, 5.275E-10,
     & 4.875E-10,4.505E-10, 4.164E-10, 3.848E-10, 3.556E-10, 3.287E-10,
     & 3.038E-10,2.808E-10, 2.595E-10, 2.399E-10, 2.217E-10, 2.049E-10,
     & 1.894E-10,1.751E-10, 1.618E-10, 1.496E-10, 1.383E-10, 1.278E-10,
     & 1.182E-10,1.092E-10, 1.010E-10, 9.334E-11, 8.628E-11, 7.976E-11,
     & 7.374E-11,6.817E-11, 6.302E-11, 5.826E-11, 5.386E-11, 4.980E-11,
     & 4.604E-11,4.257E-11, 3.935E-11, 3.639E-11, 3.364E-11, 3.110E-11,
     & 2.876E-11,2.659E-11, 2.459E-11, 2.273E-11, 2.102E-11, 1.944E-11,
     & 1.797E-11,1.662E-11, 1.537E-11, 1.421E-11, 1.314E-11, 1.215E-11,
     & 1.123E-11,1.039E-11, 9.607E-12, 8.884E-12, 8.216E-12, 7.598E-12,
     & 7.026E-12,6.498E-12, 6.009E-12, 5.557E-12, 5.139E-12, 4.753E-12,
     & 4.396E-12,4.065E-12, 3.760E-12, 3.477E-12, 3.216E-12, 2.974E-12,
     & 2.751E-12,2.544E-12, 2.353E-12, 2.177E-12, 2.013E-12, 1.862E-12,
     & 1.722E-12,1.593E-12, 1.473E-12, 1.363E-12, 1.261E-12, 1.166E-12,
     & 1.079E-12,9.977E-13, 9.229E-13, 8.537E-13, 7.897E-13, 7.305E-13,
     & 6.757E-13,6.251E-13, 5.782E-13, 5.349E-13/
 
      if (xt .lt. .1) then
        e1 = -log(xt)-0.57721+xt
      else if (xt .gt. 25.) then
         e1 = expx/xt*(1.-0.95/xt)
      else
         r = (xt-deoff)/dexp1+1.0
         intr = int(r)
         frac = r-real(intr)
         e1 = e1data(intr)*(1.-frac)+e1data(intr+1)*frac
      endif
      ex1=e1
      return
      end
 

      function phicx(xx)
      implicit real*8 (a-h,o-z)
      common /phistuff/ cp0,cp1,cp2,cp3,xn,cep,cem
      phicx=exp(cp0+xx*(cp1+xx*(cp2+xx*cp3)))
      return
      end


      subroutine checkbf
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      dimension pop(maxpop)

      common /dhsocc/nobm,noc1(100),noc2(100)
      common /phistuff/ cp0,cp1,cp2,cp3,xn,cep,cem
      common /phiscof/ cphi(8,10,100),xphi(10,49,100)

      parameter(mxbf=200000)
      common /transf/ntrf(maxion),ipsh(mxbf,maxion),
     &     npsh(mxbf,maxion)
      common /rtransf/
     &     epsh(mxbf,maxion),gpl(mxbf,maxion),gpu(mxbf,maxion),
     &     ppl(mxbf,maxion),ppu(mxbf,maxion)

      common /chekbf/epfly(nlvi,nlvi,maxion),
     &     ebfly(nlvi,nlvi,maxion),obfly(nlvi,nlvi,maxion)

      common /lattice/rlattice,zbar0,ene0,ievolve
      data pi /3.1415926/

       character*3 let(36)
       data let/'1s ','2s ','2p-','2p+',
     &      '3s ','3p-','3p+','3d-','3d+',
     &      '4s ','4p-','4p+','4d-','4d+','4f-','4f+',
     &      '5s ','5p-','5p+','5d-','5d+','5f-','5f+','5g-','5g+',
     &      '6s ','6p-','6p+','6d-','6d+','6f-','6f+','6g-','6g+',
     &            '6h-','6h+'/

       external phicx
c---------------------------------------------------------------
c
c___create bound-free emissivity and opacity.
c   BF transitions of outer electron from the bound states
c     emissivity = (2hv^3/c^2) * n' exp(-hv/kT) c.x(v)
c     c.x (v)= 4.12e26 * I^2.5 /zeff / v^3 * pn
c     rlte = (1.66d-22*ene)*(gl/gu)/tev**1.5 * exp(I/kT)
c     n' = rlte * pu 

      do j=1,numpop
         pop(j) = ppop(j,itimes)
      enddo
      nmx=int(xtem(itimes))
      
c     BF transitions 
      nobm=nprim
      totpop=totpin(itimes)
      ebfmax=0.d0
      obfmax=0.d0
      do 64 k=1, iion
         debyek=debye(k)
         do 65 i=1, naatot(k)
            pl = pop(incnt(k)+i)
            if(pl.eq.0.d0) goto 65
c --------- Hydrogenic Cross-sections --------------
            do ip=1,nobm
               noc1(ip)=nocel(i,k,ip)
            enddo
            gl = gfn(i,k)
            do 66 iu=1, naatot(k-1)
               pu = pop(incnt(k-1)+iu)
               if(pu.eq.0.d0) goto 66
               do ip=1,nprim
                  noc2(ip)=nocel(iu,k-1,ip)
               enddo
               call getiob(n1,n2)
               if(n1.gt.0.and.n2.eq.0)then
                  gu = gfn(iu,k-1)
                  eip=eipz(k)+evfn(iu,k-1)-evfn(i,k)-debyek
                  epfly(i,iu,k)=eip
                  ebfly(i,iu,k)=0.d0
                  obfly(i,iu,k)=0.d0
                  xn =cphi(5,n1,k)
                  if(xn.gt.0.d0) then
                     cp0=cphi(1,n1,k)
                     cp1=cphi(2,n1,k)
                     cp2=cphi(3,n1,k)
                     cp3=cphi(4,n1,k)
                     cep=cphi(6,n1,k)
                     cem=cphi(7,n1,k)

c     Scofield Photoionization Cross-sections 2012-08-09 (Orlando)
                     enemi=min(eip,cep)
                     conphi = 1.d-18*(13.606/enemi)*xn
                     oxx=conphi*pl

                     do ii=1,nmx
                        tev=tevm(ii,itimes)
                        frc=fnem(ii,itimes)
                        olt=(1.66d-22*ene)*(gl/gu)/tev**1.5
                        exx=2.08d-4*olt*conphi*pu
                        phix=phicx(0.d0)
                        o = eip*1.01
                        xx=log(o/enemi)
                        obfly(i,iu,k)=obfly(i,iu,k)+frc*oxx*phicx(xx)
                        ebfly(i,iu,k)=ebfly(i,iu,k)+frc*exx*phicx(xx)*
     &                                o**3*exp((eip-o)/tev)
                        obfly(i,iu,k)=obfly(i,iu,k)-frc*oxx*phicx(xx)*
     &                       olt*(pu/pl)*exp((eip-o)/tev)
                     enddo
                  else
                     pn=noc1(n1)
                     zeff=sqq(i,k)
                     conphi = 2.91437d-17*eip**2.5/zeff*pn ! kramer c.x. in eV
                     oxx=conphi*pl
                     do ii=1,nmx
                        tev=tevm(ii,itimes)
                        frc=fnem(ii,itimes)
                        olt=(1.66d-22*ene)*(gl/gu)/tev**1.5
                        exx=2.08d-4*olt*conphi*pu
                        phix=conphi/eip**3
                        o = eip*1.01
                        obfly(i,iu,k)=obfly(i,iu,k)+frc*oxx/o**3
                        ebfly(i,iu,k)=ebfly(i,iu,k)+
     &                       frc*exx*exp((eip-o)/tev)
                        obfly(i,iu,k)=obfly(i,iu,k)-frc*oxx/o**3*
     &                       olt*(pu/pl)*exp((eip-o)/tev)
                     enddo
                  endif
                  ebfmax=max(ebfmax,ebfly(i,iu,k))
                  obfmax=max(obfmax,obfly(i,iu,k))
               endif
 66         continue
 65      continue
c------------------------------------------------------------------
 64   continue

      do k=1, iion
         do i=1, naatot(k)
            do iu=1, naatot(k-1)
               ebfly(i,iu,k)=ebfly(i,iu,k)/ebfmax
               obfly(i,iu,k)=obfly(i,iu,k)/obfmax
            enddo
         enddo
      enddo
      return
      end
      
c**********************************************************************
c     xrn mode: bound-bound lines from the FLYSPEC transition list
c     (xrn.ZZ) instead of the SCFLY detailed files (trn.ZZII).
c
c     Activated by the control file 'xrnspect.inp':
c       line 1: xrn file name (e.g. xrn.29), or 'none' for trn mode
c       line 2: FLYCHK file whose level indices the xrn file uses,
c               or 'same' when the population file is that file
c       line 3: 1 to include Stark widths (starkw), 0 to omit them
c     Without 'xrnspect.inp' the program runs in the original trn mode.
c
c     Line physics follows FLYSPEC (zmkspec_tev.f: readtrn, mkgamma)
c**********************************************************************
      subroutine xrninit
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'xrncom.inc'
      logical around

      lxrn=.false.
      istkx=1
      iprof=1
      ibfx=1
      reffile='same'
      write(xrnfile,'("xrn.",i2.2)') iion

      inquire(file='xrnspect.inp',exist=around)
      if(.not.around) return

      open(41,file='xrnspect.inp')
      read(41,'(a80)',end=5) xrnfile
      read(41,'(a80)',end=5) reffile
      read(41,*,end=5) istkx
      read(41,*,end=5) iprof
      read(41,*,end=5) ibfx
 5    close(41)
      xrnfile=adjustl(xrnfile)
      reffile=adjustl(reffile)
      if(xrnfile(1:4).eq.'none') return

      inquire(file=trim(xrnfile),exist=around)
      if(.not.around) then
         print *, 'xrn file not found: ', trim(xrnfile)
         stop
      endif
      lxrn=.true.
      write(*,'("xrn mode: lines from ",a," ; level reference ",a,
     &     " ; stark ",i2," ; profile ",i2," ; bf ",i2)')
     &     trim(xrnfile),trim(reffile),istkx,iprof,ibfx

      do iso=0,iion
         do j=1,nlvi
            rtg0(j,iso)=rtgam(j,iso)
         enddo
      enddo

      call xrnmap
      call xrnload
      call xrnphil
      call xrnbfset

      return
      end

c**********************************************************************
      subroutine xrnbfset
c     ionization pairs (number of electrons, shell, continuum level)
c     as FLYSPEC subfile: ietf, nishf, ncof
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'xrncom.inc'
      dimension noc1(25),noc2(25)

      do iz=1,iion
         do i=1,nlvi
            ncof(i,iz)=0
            do j=1,nlvi
               ietf(i,j,iz)=0
               nishf(i,j,iz)=0
            enddo
         enddo
      enddo

      do iz=1,iion
         do i=1,naatot(iz)
            do ip=1,nprim
               noc1(ip)=nocel(i,iz,ip)
            enddo
            mi=morb(i,iz)
            do j=1,naatot(iz-1)
               do ip=1,nprim
                  noc2(ip)=nocel(j,iz-1,ip)
               enddo
               mj=0
               if(iz.gt.1) mj=morb(j,iz-1)
               call getlnpqs(noc1,noc2,n1,n2,nprim)
               if(mi.gt.nprim)then
                  if(mj.eq.mi)then
                     if(n1.gt.0.and.n2.eq.0) then
                        ietf(i,j,iz)=noc1(n1)
                        nishf(i,j,iz)=n1
                     endif
                  else
                     if(n1.eq.0.and.n2.eq.0) then
                        ietf(i,j,iz)=1
                        nishf(i,j,iz)=mi
                     endif
                  endif
               else
                  if(n1.gt.0.and.n2.eq.0) then
                     ietf(i,j,iz)=noc1(n1)
                     nishf(i,j,iz)=n1
                  endif
               endif
               if(ietf(i,j,iz).ne.0.and.mi.eq.n1)then
                  if(.not.(iz.eq.4.and.ncof(i,iz).ne.0)) ncof(i,iz)=j
               elseif(ietf(i,j,iz).ne.0.and.mi.gt.nprim)then
                  ncof(i,iz)=j
               endif
            enddo
            if(ncof(i,iz).eq.0) ncof(i,iz)=ncont(i,iz)
         enddo
      enddo
c     Li-like inner-shell ionization corrections (FLYSPEC, Z<=26)
      if(iion.le.26.and.iion.ge.3) then
         do j=4,5
            ietf(1,j,3)=0
         enddo
         do j=2,3
            ietf(2,j,3)=0
         enddo
      endif
      return
      end

c**********************************************************************
      subroutine xrnmap
c     maps xrn level indices (reference FLYCHK structure) onto the
c     level indices of the population file by shell occupations
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'xrncom.inc'
      character*200 line
      character*8 nam
      dimension nr(10)
      logical used(nlvi)

      do iso=1,maxion
         nrefl(iso)=0
         nmapok(iso)=0
         do j=1,nlvi
            mapfs(j,iso)=0
         enddo
      enddo

      if(reffile(1:4).eq.'same') then
         do iso=1,iion
            nrefl(iso)=naatot(iso)
            nmapok(iso)=naatot(iso)
            do j=1,naatot(iso)
               mapfs(j,iso)=j
            enddo
         enddo
         return
      endif

      open(42,file=trim(reffile),status='old')
      isoc=0
      npr=nprim
 10   read(42,'(a200)',end=20) line
      if(line(1:4).eq.'enot') then
         read(line,'(4x,2i5)') isoc,npr
         if(isoc.ge.1.and.isoc.le.iion) then
            do j=1,nlvi
               used(j)=.false.
            enddo
         endif
         goto 10
      endif
      if(line(1:4).ne.'elev') goto 10
      read(line,'(4x,2i4,1x,a8)') iso,jr,nam
      if(iso.ne.isoc.or.iso.lt.1.or.iso.gt.iion) goto 10
      if(jr.lt.1.or.jr.gt.nlvi) goto 10
      do ip=1,10
         nr(ip)=0
      enddo
      read(line(68:),'(10i3)') (nr(ip),ip=1,npr)
      read(line(68+3*npr+1:68+3*npr+4),'(i4)') mr
      nrefl(iso)=max(nrefl(iso),jr)

c     exact match of occupations and active shell, then occupations only
      do ipass=1,2
         do j=1,naatot(iso)
            if(used(j)) goto 30
            do ip=1,10
               if(nocel(j,iso,ip).ne.nr(ip)) goto 30
            enddo
            if(ipass.eq.1.and.morb(j,iso).ne.mr) goto 30
            mapfs(jr,iso)=j
            used(j)=.true.
            nmapok(iso)=nmapok(iso)+1
            goto 10
 30         continue
         enddo
      enddo
      write(*,'("  xrn map: no level for ",i3,i4,1x,a8)') iso,jr,nam
      goto 10
 20   close(42)

      do iso=1,iion
         if(nrefl(iso).gt.0.and.nmapok(iso).lt.nrefl(iso))
     &        write(*,'("  xrn map iso",i3,": ",i4," of ",i4,
     &        " reference levels mapped")') iso,nmapok(iso),nrefl(iso)
      enddo
      return
      end

c**********************************************************************
      subroutine xrnload
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'xrncom.inc'

      nxrn=0
      do iso=1,maxion
         nxskip(iso)=0
      enddo
      open(43,file=trim(xrnfile),status='old')
 10   read(43,*,end=20) iso,il,iu,n1,n2,euln,flu,avalue,det,wix
      if(iso.lt.1.or.iso.gt.iion) goto 10
      if(il.lt.1.or.il.gt.nlvi.or.iu.lt.1.or.iu.gt.nlvi) then
         nxskip(iso)=nxskip(iso)+1
         goto 10
      endif
      mil=mapfs(il,iso)
      miu=mapfs(iu,iso)
      if(n1.lt.0.or.n2.lt.0.or.n1.gt.100.or.n2.gt.100) then
         nxskip(iso)=nxskip(iso)+1
         goto 10
      endif
      if(il.eq.iu.and.(n1.eq.0.or.n2.eq.0)) then
         nxskip(iso)=nxskip(iso)+1
         goto 10
      endif
      if(mil.eq.0.or.miu.eq.0) then
         nxskip(iso)=nxskip(iso)+1
         goto 10
      endif
      if(nxrn.ge.mxxrn) then
         print *, 'too many xrn lines > ', mxxrn
         stop
      endif
      nxrn=nxrn+1
      ixiso(nxrn)=iso
      ixl(nxrn)=mil
      ixu(nxrn)=miu
      ixn1(nxrn)=n1
      ixn2(nxrn)=n2
      xeu(nxrn)=euln
      xfl(nxrn)=flu
      xav(nxrn)=avalue
      xdet(nxrn)=det
      xwix(nxrn)=wix
      goto 10
 20   close(43)

      nsk=0
      do iso=1,iion
         nsk=nsk+nxskip(iso)
         if(nxskip(iso).gt.0) write(*,'("  xrn iso",i3,": ",i6,
     &        " lines skipped (unmapped level or bad orbital)")')
     &        iso,nxskip(iso)
      enddo
      write(*,'("  xrn lines loaded: ",i8,"  skipped: ",i8)')nxrn,nsk
      return
      end

c**********************************************************************
      subroutine xrnphil
c     Scofield photoionization fits for bound-free (as FLYSPEC dchkphi)
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'xrncom.inc'
      dimension cp(8)
      logical around

      do iso=1,100
         do ish=1,10
            do ii=1,8
               cphix(ii,ish,iso)=0.d0
            enddo
         enddo
      enddo
      inquire(file='phistuf',exist=around)
      if(.not.around) then
         print *, ' phistuf not found: Kramers bound-free used'
         return
      endif
      open(44,file='phistuf')
      n=0
 10   read(44,*,end=20) iz,iso,ish,(cp(ii),ii=1,8)
      if(iz.eq.iion.and.iso.ge.1.and.iso.le.100.and.
     &     ish.ge.1.and.ish.le.10) then
         do ii=1,8
            cphix(ii,ish,iso)=cp(ii)
         enddo
         n=n+1
      endif
      goto 10
 20   close(44)
      write(*,'("  phistuf: ",i4," Scofield fits for Z=",i3)') n,iion
      return
      end

c**********************************************************************
      subroutine readxrn
      implicit double precision(a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      include 'xrncom.inc'

      common /bandstr/band(10),fwhml
      common /etrn/emitx,emimx(nlvi,nlvi,maxion),konly(maxion),
     &     ionly(nlvi,maxion),itonly(nlvi,nlvi,maxion)
      logical ionly,konly
      common /phiscof/ cphi(8,10,100),xphi(10,49,100)
      parameter(mxbf=200000)
      common /transf/ntrf(maxion),ipsh(mxbf,maxion),
     &     npsh(mxbf,maxion)

      dimension pop(maxpop),emion(maxion),jj(100)
      dimension fnlx(nlvi,nlvi,maxion)
      save fnlx
      external voigt

       character*3 let(100)
       data let/'1s ','2s ','2p-','2p+',
     &      '3s ','3p-','3p+','3d-','3d+',
     &      '4s ','4p-','4p+','4d-','4d+','4f-','4f+',
     &      '5s ','5p-','5p+','5d-','5d+','5f-','5f+','5g-','5g+',
     &      '6s ','6p-','6p+','6d-','6d+','6f-','6f+','6g-','6g+',
     &            '6h-','6h+',
     &      '7s ','7p-','7p+','7d-','7d+','7f-','7f+','7g-','7g+',
     &            '7h-','7h+','7i-','7i+', 51*'n>7'/

      evtohz=2.417969d14
      const=2.333325d-15
      cone=1.2749813d-13
      cwd= 4.6337d-5 *sqrt(tiev/(2.d0*iion))

c     2J+1 of the relativistic subshells (as FLYSPEC shapit)
      do i=1,10
         do j=1,2*i-1
            iorb=(i-1)**2+j
            jj(iorb)=int((int((j-1)/2)+0.5d0)*2.d0+1.d0)
         enddo
      enddo

      totpop=totpin(itimes)
      do j=1,numpop
         pop(j)=ppop(j,itimes)
      enddo
      nmx=int(xtem(itimes))
      tevhi=tevm(nmx,itimes)
      tevv=tevm(1,itimes)
      frc=fnem(1,itimes)

c     bound-free: Scofield fits for every level (no detailed trn data)
      do iso=1,min(iion,100)
         do ish=1,10
            do ii=1,8
               cphi(ii,ish,iso)=cphix(ii,ish,iso)
            enddo
         enddo
      enddo
      do iso=0,iion
         do k=1,nlvi
            gtev(k,iso)=0.d0
         enddo
      enddo
      gtev(1,0)=1.d0
      do iso=isomin,isomax
         ntrf(iso)=0
      enddo
      do i=1,mxistg
         ntri(i)=0
      enddo

      do iso=max(1,isomin),isomax
         call mkgamx(iso)
      enddo

c     departure from Boltzmann between levels (FLYSPEC fnlte)
      do iso=max(1,isomin),isomax
         do iu=1,naatot(iso)
            do il=1,naatot(iso)
               fnlx(iu,il,iso)=0.d0
               if(iu.eq.il) goto 40
               pu=pop(incnt(iso)+iu)
               pl=pop(incnt(iso)+il)
               if(pu.lt.1.d-30) goto 40
               if(pl/totpop.lt.1.d-22) goto 40
               etran=evfn(iu,iso)-evfn(il,iso)
               if(pl.gt.1.d-30.and.etran/tevhi.lt.200.)then
                  fnlx(iu,il,iso)=(pu/pl)/
     &                 (gfn(iu,iso)/gfn(il,iso)*exp(-etran/tevhi))
               endif
 40            continue
            enddo
         enddo
      enddo

      emitx=0.d0
      do iso=1,maxion
         emion(iso)=0.d0
      enddo
      nover=0

c     pass 1 selects the emitting ions, pass 2 builds their lines
      do 500 ipass=1,2
      do 400 n=1,nxrn
         iso=ixiso(n)
         if(iso.lt.isomin.or.iso.gt.isomax) goto 400
         if(ipass.eq.2) then
            k=indion(iso)
            if(k.eq.0) goto 400
         endif
         euln=xeu(n)
         if(euln.lt.0.99*emin.or.euln.gt.1.01*emax) goto 400
         il=ixl(n)
         iu=ixu(n)
         pu=pop(incnt(iso)+iu)
         pl=pop(incnt(iso)+il)
         if(pu.lt.1.d-30) goto 400
         if(pl/totpop.lt.1.d-22) goto 400
         flu=xfl(n)
         avalue=xav(n)
         det=xdet(n)
         wix=xwix(n)
         n1=ixn1(n)
         n2=ixn2(n)
         ffnlte=0.d0
         if(iu.ne.il) then
            if(ipass.eq.2) then
               ffnlte=fnlx(iu,il,iso)
               if(ffnlte.gt.0.9)then
                  pu=ffnlte*pl*gfn(iu,iso)/gfn(il,iso)
     &                 *exp(-euln/tevhi)
                  flu=avalue*gfn(iu,iso)/gfn(il,iso)/euln**2
     &                 /4.34327d7
               endif
            endif
         else
c           delta_n=0 within one superconfiguration: two-level partition
            if(wix.lt.1.) wix=1.
            gugl=jj(n2)*1.d0/jj(n1)
            flu=avalue/euln**2/4.34327d7*gugl
            ebt = euln/tevv
            gaunt = 0.15 + 0.28*exp1x(ebt)
            clu=frc*ene*1.578d-5/euln*flu*gaunt/sqrt(tevv)*exp(-ebt)
            cul=frc*ene*1.578d-5/euln*flu*gaunt/sqrt(tevv)/gugl
            ffnlte=clu/(clu+cul+avalue)
            pu=ffnlte*pu
            pl=(1.-ffnlte)*pl
         endif

         if(ipass.eq.1) then
            emiln=pu*avalue*euln
            emion(iso)=max(emion(iso),emiln)
            emitx=max(emitx,emiln)
            goto 400
         endif

         oplx=0.0265*pl*flu*(1.0-ffnlte*exp(-euln/tevhi))
         emlx=cone*pu*avalue*euln

         winst=min(euln/2000.1,1.d0)
         zeff=dble(iion-iso)
         width=0.d0
         if(istkx.ne.0) then
            n1q=morb(il,iso)
            n2q=morb(iu,iso)
            q1=sqq(il,iso)
            q2=sqq(iu,iso)
            call starkw(n1q,n2q,q1,q2,dble(iion),zeff,
     &           ene,totpop,tev,tiev,ene/totpop,width)
         endif
         wd=sqrt((cwd*euln)**2+(0.53*width)**2)+max(det,wix,winst)
         npq=morb(iu,iso)
         if(npq.ge.1.and.npq.le.10) wd=wd+band(npq)
         wd=wd+fwhm
         gamx=rtgam(iu,iso)+rtgam(il,iso)+0.11*width*evtohz+fwhml
         avx=gamx/(wd*12.57*evtohz)

         phi0=const/wd*voigt(0.d0,avx)
         taufn=oplx*phi0*size
         if(taufn.lt.1.d-6.or.oplx.le.0.d0) then
            flx=emlx*phi0*size
         else
            flx=emlx/oplx*(1.-exp(-taufn))
         endif
         if(flx.lt.1.d-70) goto 400

         if(ntri(k).ge.linmax) then
            nover=nover+1
            goto 400
         endif
         ntri(k)=ntri(k)+1
         itr=ntri(k)
         ei(itr,k)=euln
         fln(itr,k)=flu
         opl(itr,k)=oplx
         eml(itr,k)=emlx
         wdt(itr,k)=wd
         avt(itr,k)=avx

         if(pu/totpop.gt.1e-12.or.pl/totpop.gt.1.e-8) then
            if(n1.ge.1.and.n2.ge.1) then
               write(20,'(i2,1x,f10.3,1p,8e10.2,2x,2i4,2x,2(1x,a8))')
     &              iso,euln,flx,emlx,taufn,avalue,wd,gamx/evtohz,
     &              pu,pl,iu,il,let(n1),let(n2)
            else
               write(20,'(i2,1x,f10.3,1p,8e10.2,2x,2i4,2x,2(1x,a8))')
     &              iso,euln,flx,emlx,taufn,avalue,wd,gamx/evtohz,
     &              pu,pl,iu,il,namlev(il,iso),namlev(iu,iso)
            endif
         endif
 400  continue

      if(ipass.eq.1) then
c        keep ions whose strongest line exceeds eminx of the maximum
         eminx=1.d-6
 450     nsel=0
         do iso=isomin,isomax
            konly(iso)=.false.
            if(emitx.gt.0.d0) then
               if(emion(iso)/emitx.gt.eminx) then
                  konly(iso)=.true.
                  nsel=nsel+1
               endif
            endif
         enddo
         if(nsel.gt.mxistg) then
            eminx=eminx*2.d0
            goto 450
         endif
         k=0
         do iso=isomin,isomax
            indion(iso)=0
            if(konly(iso)) then
               k=k+1
               indion(iso)=k
               index(k)=iso
            endif
         enddo
         kmx=k
      endif
 500  continue

      do iso=isomin,isomax
         k=indion(iso)
         if(k.ne.0) write(*,'("ion: ",i2,"   bb= ",i6)') iso,ntri(k)
      enddo
      if(nover.gt.0) print *, 'lines dropped above linmax: ', nover

      return
      end

c**********************************************************************
      subroutine specbfx
c     bound-free emissivity/opacity as FLYSPEC specbf:
c     Scofield fits (phistuf) per ionized shell, else Kramers
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'spect.inc'
      include 'xrncom.inc'
      common /phistuff/ cp0,cp1,cp2,cp3,xn,cep,cem
      dimension pop(maxpop),selct(nlvi)
      dimension iex(nlvi,0:maxion)
      external phicx

      do j=1,numpop
         pop(j)=ppop(j,itimes)
      enddo
      ntem=int(xtem(itimes))

c     Be-like ground-state photoionization weights (FLYSPEC)
      do i=1,nlvi
         selct(i)=0.d0
      enddo
      if(iion.le.26) then
         j1=20
         j2=25
      else
         j1=22
         j2=51
      endif
      gbe=0.d0
      do j=j1,min(j2,naatot(3))
         gbe=gbe+gfn(j,3)
      enddo
      if(gbe.gt.0.d0) then
         do j=j1,min(j2,naatot(3))
            selct(j)=gfn(j,3)/gbe
         enddo
      endif

c     level existence with continuum lowering (FLYSPEC iexist)
      iex(1,0)=1
      do k=1,iion
         dbk=debye(k)
         do i=1,naatot(k)
            iex(i,k)=1
            ii=ncof(i,k)
            if(ii.gt.0) then
               if(eipz(k)+evfn(ii,k-1)-evfn(i,k).lt.dbk) iex(i,k)=0
            endif
         enddo
      enddo
      do k=1,iion
         if(iex(1,k).ne.0)then
            do j=1,naatot(k-1)
               if(nishf(1,j,k).gt.0.and.nishf(1,j,k).lt.morb(1,k))
     &              iex(j,k-1)=2
            enddo
         endif
      enddo

      cp0=0.d0
      cp1=0.d0
      cp2=0.d0
      cp3=0.d0
      xn=0.d0
      cep=0.d0
      cem=0.d0

      do 64 k=1,iion
         dbk=debye(k)
         zeff=dble(iion-k)+1.d0
         do 65 i=1,naatot(k)
            if(sqq(i,k).gt.1.d-30) zeff=sqq(i,k)
            if(iex(i,k).eq.0) goto 65
            gl=gfn(i,k)
            pl=pop(incnt(k)+i)
            do 66 iu=1,naatot(k-1)
               if(iex(iu,k-1).eq.0) goto 66
               if(ietf(i,iu,k).eq.0) goto 66
               gu=gfn(iu,k-1)
               pu=pop(incnt(k-1)+iu)
               eip=eipz(k)+evfn(iu,k-1)-evfn(i,k)-dbk
               if(eip.le.1.d-30) goto 66
               rpul=0.d0
               if(pl.gt.0.d0) rpul=pu/pl
               pn=ietf(i,iu,k)
               ish=nishf(i,iu,k)
               if(ish.ge.1.and.ish.le.10)then
                  cp0=cphix(1,ish,k)
                  cp1=cphix(2,ish,k)
                  cp2=cphix(3,ish,k)
                  cp3=cphix(4,ish,k)
                  xn =cphix(5,ish,k)
                  cep=cphix(6,ish,k)
                  cem=cphix(7,ish,k)
               endif
               do 70 ii=1,ntem
                  tex=tevm(ii,itimes)
                  frc=fnem(ii,itimes)
                  olt=(1.66d-22*ene)*(gl/gu)/tex**1.5
                  if(xn.le.0.d0.or.ish.gt.10.or.ish.lt.1)then
c                    Kramers cross section
                     ccx2=2.91437d-17*eip**2.5/zeff*pn
                     oxx=ccx2*pl
                     exx=2.08d-4*olt*ccx2*pu
                     do j=1,jtotal
                        o=e(j)
                        if(o.gt.eip) then
                           bx=exp(max((eip-o)/tex,-700.d0))
                           ebf(j)=ebf(j)+frc*exx*bx
                           obf(j)=obf(j)+frc*oxx/o**3*(1.-olt*rpul*bx)
                        endif
                     enddo
                     write(21,'("k",i4,1x,f10.3,1p,6e10.2,2x,2i4)')
     &                    k,eip,exx,oxx/eip**3,tex,frc,pl,pu,i,iu
                  else
c                    Scofield fit; K-edge of non-K ions from the fit
                     if(ish.eq.1.and.k.gt.2) eip=cep-dbk
                     enemi=cep
                     if(k.eq.4.and.i.eq.1)then
                        conphi=1.d-18*(13.606/enemi)*xn*selct(iu)
                     else
                        conphi=1.d-18*(13.606/enemi)*xn
                     endif
                     oxx=conphi*pl
                     exx=2.08d-4*olt*conphi*pu
                     xxm=log(cem/enemi)
                     phicxm=phicx(xxm)*cem**3
                     do j=1,jtotal
                        o=e(j)
                        if(o.gt.eip.and.o.le.cem) then
                           xx=max(0.d0,log(o/enemi))
                           bx=exp(max((eip-o)/tex,-700.d0))
                           px=phicx(xx)
                           ebf(j)=ebf(j)+frc*exx*px*o**3*bx
                           obf(j)=obf(j)+frc*oxx*px*(1.-olt*rpul*bx)
                        else if(o.gt.cem) then
                           bx=exp(max((eip-o)/tex,-700.d0))
                           ebf(j)=ebf(j)+frc*exx*phicxm*bx
                           obf(j)=obf(j)+frc*oxx*phicxm/o**3*
     &                          (1.-olt*rpul*bx)
                        endif
                     enddo
                     write(21,'("s",i4,1x,f10.3,1p,6e10.2,2x,2i4)')
     &                    k,eip,exx*phicx(0.d0)*eip**3,oxx*phicx(0.d0),
     &                    tex,frc,pl,pu,i,iu
                  endif
 70            continue
 66         continue
 65      continue
 64   continue

      return
      end

c**********************************************************************
      subroutine mkgamx(iz)
c     Lorentzian width rate: radiative+autoionization (rtg0) plus
c     electron collisional excitation/ionization (FLYSPEC mkgamma)
      implicit real*8 (a-h,o-z)
      include 'ilvcom.inc'
      include 'xrncom.inc'
      dimension cxgam(nlvi)

      evtohz=2.417969d14
      do j=1,naatot(iz)
         rtgam(j,iz)=rtg0(j,iz)
         cxgam(j)=0.d0
      enddo
      ntem=int(xtem(itimes))
      dbz=debye(iz)

      do 101 iu=1,naatot(iz)
         ii=ncof(iu,iz)
         if(ii.le.0) goto 101
         eip=eipz(iz)+evfn(ii,iz-1)-evfn(iu,iz)-dbz
         if(eip.le.0.d0) goto 101
         gu=gfn(iu,iz)
         pn=ietf(iu,ii,iz)
         do ite=1,ntem
            tex=tevm(ite,itimes)
            frc=fnem(ite,itimes)
            ebt=eip/tex
            if(ebt.lt.500.) then
               cxgam(iu)=cxgam(iu)+frc*
     &              ene*2.97e-6/(sqrt(tex)*eip)*ex1(ebt,exp(-ebt))*pn
            endif
         enddo

         do 100 il=1,iu-1
            iil=ncof(il,iz)
            if(iil.le.0) goto 100
            eipl=eipz(iz)+evfn(iil,iz-1)-evfn(il,iz)-dbz
            if(eipl.le.0.d0) goto 100
            gl=gfn(il,iz)
            eji=evfn(iu,iz)-evfn(il,iz)
            if(eji.le.0.d0) goto 100
            fij=aratefn(iu,il,iz)*gu/gl/eji**2/4.34327d7
            if(fij.le.0.d0) goto 100
            do ite=1,ntem
               tex=tevm(ite,itimes)
               frc=fnem(ite,itimes)
               ebt=eji/tex
               gaunt=0.15+0.28*exp1x(ebt)
               cxgam(il)=cxgam(il)+frc*
     &              ene*1.578d-5/eji*fij*gaunt/sqrt(tex)*exp(-ebt)
               cxgam(iu)=cxgam(iu)+frc*
     &              ene*1.578d-5/eji*fij*gaunt/sqrt(tex)*gl/gu
            enddo
 100     continue
 101  continue

      do iu=1,naatot(iz)
         ii=ncof(iu,iz)
         if(ii.le.0) goto 102
         eip=eipz(iz)+evfn(ii,iz-1)-evfn(iu,iz)-dbz
         if(eip.gt.0.d0.and.morb(iu,iz).gt.0)then
            dEhz=2.*eip/morb(iu,iz)*evtohz
            cxgam(iu)=min(cxgam(iu),dEhz)
            rtgam(iu,iz)=rtgam(iu,iz)+cxgam(iu)
         endif
 102     continue
      enddo

      return
      end

c *********************************************************************

      subroutine starkw(n1,n2,q1,q2,z,zeff,ne,ni,tev,tiv,zbar,width)

c .....................................................................
c
c   This routine estimates the FWHM of a Stark-broadened line using a
c   variety of fits and formulas.
c
c   For Z from 6-18, for hydrogen-like or helium-like beta and delta
c   lines, use analytic fits from Dick Lee.
c
c   For high-lying Balmer and Paschen lines of hydrogen, use newer
c   analytic fits from Dick Lee.
c
c   For low-lying Lyman and Balmer lines of hydrogen, use the numbers
c   and scalings from Hans Griem's book "Spectral line Broadening by
c   Plasmas"
c   
c   The preceding possiblities all apply within restricted ranges
c   of temperature and electron density (although all are applied for
c   lower electron densities by extending the scaling formulas).
c
c   If none of these conditions are met, use some formulas from Hans
c   Griem to estimate the width.  The formulas were designed for high
c   densities (appropriate to ICF).  They do not distinguish odd and
c   even delta-n's and can overestimate the low-density widths of odd
c   delta-n transitions.  Multiply these by 0.25 (as suggested by
c   Stephanie Hansen).
c
c   Cap the maximum width at the distance to the next line in a
c   hydrogenic sequence.  Broadening beyond that is unphysical due
c   to level repulsion.
c
c   Finally, estimate the width due to the fine structure and use
c   that as a minimum value - for hydrogen only.
c
c .....................................................................
c
c     ARGUMENTS
c     ---------
c
c     INPUT:
c        n1, n2 : principle quantum numbers for levels 1,2
c        q1, q2 : effective core charges for levels 1,2 (dimensionless)
c        z      : nuclear charge of radiator
c        zeff   : effective charge of radiator
c        ne     : electron density (1/cm^3)
c        ni     : ion density (1/cm^3)
c        tev    : electron temperature (eV)
c        tiv    : ion temperature (eV)
c        zbar   : average ion charge of neighbors (dimensionless)
c
c     OUTPUT:
c        width  : FWHM line width (eV)
c
c .....................................................................

      implicit none

      integer           n1, n2
      double precision  q1, q2, z, zeff, ne, ni, tev, tiv, zbar, width

      integer           indx, itab
      integer           j1, j2, jtab
      double precision  ai, bi, ci, di
      double precision  de, defs, demin, demax
      double precision  f1, frac, fx1, fx2
      double precision  pn, pn1, pn2
      double precision  rei, rzi
      double precision  xne
      double precision  y
      double precision  wd1, wd2, wdelec, wdion, wfine, wnext

      double precision  exp1x

      double precision  zero, one, two, three, four, six, nine
      double precision  half, third, two3rd
      parameter (zero = 0.d0, one = 1.d0, two = 2.d0, three = 3.d0)
      parameter (four = 4.d0, six = 6.d0, nine = 9.d0)
      parameter (half = 0.5d0, third = one/three, two3rd = two/three)

      double precision  pi, pi43, a0, ryd, pfq, hci, alphai
      data pi,pi43    / 3.1415927d0,  4.1887902d0 /
      data a0,ryd,pfq / 5.2917723d-9, 13.605692d0, 1.3788d-21 /
      data hci        / 8.0655443d-5 /
      data alphai     / 137.03600d0  /

c .....................................................................

      double precision  z1, zmin, zmax, z0, ne0
      data z1          /  2.01d0 /
      data zmin,zmax   /  6.d0, 18.d0 /
      data z0,ne0      / 12.d0, 1.d22 /

      double precision  tmin, tmax
      data tmin,tmax   / 100.d0, 1000.d0 /

      double precision  nemin, nemax
      data nemin,nemax / 1.d19, 1.d25 /

      integer    ntab
      parameter (ntab = 3)

      double precision  atab(ntab,2), btab(ntab,2), ctab(ntab,2),
     &                  dtab(ntab,2), ttab(ntab)

      data atab  /  2.669d0, 3.353d0, 3.970d0 ,
     &              6.959d0, 8.370d0, 9.721d0 /
      data btab  / -1.252d0,-1.055d0,-0.893d0 ,
     &             -1.270d0,-1.132d0,-0.975d0 /
      data ctab  /  0.546d0, 0.559d0, 0.582d0 ,
     &              0.563d0, 0.586d0, 0.604d0 /
      data dtab  / -0.008d0,-0.009d0,-0.009d0 ,
     &             -0.007d0,-0.009d0,-0.009d0 /

      data ttab  / 250.d0, 500.d0, 1000.d0 /

c .....................................................................

      integer    ntab2
      parameter (ntab2 = 4)

      double precision  ttab2(ntab2), alp82t(ntab2), alp10t(ntab2),
     &                  bet82t(ntab2), bet10t(ntab2),
     &                  alptab(6,2), bettab(6,2)

      double precision  tmin2, tmax2
      double precision  nemin2, nemax2
      data ttab2         / 0.16d0, 1.00d0, 4.00d0, 10.0d0 /
      data tmin2,tmax2   / 0.10d0, 10.0d0 /
      data nemin2,nemax2 / 1.0d19, 1.0d22 /

      data alp82t  / 0.365d0,  0.249d0, 0.228d0, 0.234d0 /
      data bet82t  / 16.72d-7, 7.17d-7, 4.10d-7, 6.98d-7 /
      data alp10t  / 0.807d0,  0.397d0, 0.366d0, 0.303d0 /
      data bet10t  / 12.00d-7, 18.8d-7, 8.80d-7, 9.05d-7 /
      data alptab  / 0.228d0,0.306d0,0.366d0,0.438d0,0.551d0,0.696d0,
     &               1.144d0,1.513d0,1.892d0,2.390d0,2.995d0,3.694d0 /
      data bettab  / 4.10d-7,5.10d-7,8.80d-7,12.8d-7,14.0d-7,13.6d-7,
     &               2.97d-7,3.56d-7,4.45d-7,4.96d-7,5.05d-7,4.76d-7 /

c .....................................................................

      integer    ngriem
      parameter (ngriem = 5)

      double precision  griem(ngriem,ngriem,2,4), tgriem(ngriem)
      integer           nlo(ngriem,2,4), nhi(ngriem,2,4)

      data tgriem / 4.3086925d-1, 8.617385d-1, 1.723477d0,
     &              2.5852155d0 , 3.446954d0 /
      data nlo    / 5*16, 5*15, 5*15, 5*14, 5*14, 5*14, 5*14, 5*13 /
      data nhi    / 19, 19, 20, 20, 20,   17, 18, 19, 19, 19,
     &              18, 18, 19, 19, 19,   17, 18, 18, 18, 18,
     &              17, 18, 18, 18, 18,   17, 17, 17, 17, 17,
     &              17, 17, 17, 17, 17,   16, 17, 17, 16, 16 /

      data griem  /
c      Lyman alpha
     &              8.31d-05, 1.33d-04, 1.71d-04, 1.47d-04, 1.47d-04,
     &              6.63d-05, 1.13d-04, 1.72d-04, 1.94d-04, 1.94d-04,
     &              5.56d-05, 9.83d-05, 1.61d-04, 2.21d-04, 2.27d-04,
     &              5.03d-05, 8.88d-05, 1.51d-04, 2.24d-04, 2.59d-04,
     &              4.70d-05, 8.21d-05, 1.44d-04, 2.23d-04, 2.77d-04,
c      Balmer alpha
     &              9.69d-03, 1.49d-02, 1.89d-02, 1.89d-02, 1.89d-02,
     &              7.77d-03, 1.34d-02, 1.86d-02, 2.15d-02, 2.15d-02,
     &              6.01d-03, 1.14d-02, 1.75d-02, 2.26d-02, 2.35d-02,
     &              4.98d-03, 1.00d-02, 1.66d-02, 2.25d-02, 2.57d-02,
     &              4.50d-03, 9.22d-03, 1.58d-02, 2.23d-02, 2.69d-02,
c      Lyman beta
     &              2.10d-03, 2.14d-03, 2.14d-03, 1.89d-03, 1.89d-03,
     &              2.16d-03, 2.23d-03, 2.30d-03, 2.24d-03, 2.24d-03,
     &              2.21d-03, 2.28d-03, 2.39d-03, 2.46d-03, 2.35d-03,
     &              2.22d-03, 2.30d-03, 2.42d-03, 2.56d-03, 2.56d-03,
     &              2.23d-03, 2.31d-03, 2.44d-03, 2.61d-03, 2.69d-03,
c      Balmer beta
     &              7.62d-02, 7.87d-02, 8.08d-02, 7.65d-02, 7.65d-02,
     &              7.74d-02, 8.03d-02, 8.40d-02, 8.51d-02, 7.81d-02,
     &              7.77d-02, 8.15d-02, 8.60d-02, 9.02d-02, 8.96d-02,
     &              7.88d-02, 8.14d-02, 8.60d-02, 9.19d-02, 9.46d-02,
     &              7.90d-02, 8.14d-02, 8.61d-02, 9.27d-02, 9.77d-02,
c      Lyman gamma
     &              4.16d-04, 8.20d-04, 2.26d-03, 2.49d-03, 2.49d-03,
     &              3.22d-04, 6.15d-04, 1.64d-03, 2.81d-03, 2.68d-03,
     &              2.54d-04, 4.77d-04, 9.88d-04, 2.84d-03, 3.22d-03,
     &              2.25d-04, 4.21d-04, 8.37d-04, 2.72d-03, 3.45d-03,
     &              2.07d-04, 3.84d-04, 7.45d-04, 2.56d-03, 3.58d-03,
c      Balmer gamma
     &              4.42d-02, 8.60d-02, 9.49d-02, 8.54d-02, 8.54d-02,
     &              2.54d-02, 8.01d-02, 9.93d-02, 1.01d-01, 1.01d-01,
     &              1.79d-02, 6.30d-02, 9.89d-02, 1.11d-01, 1.11d-01,
     &              1.55d-02, 3.82d-02, 9.68d-02, 1.14d-01, 1.14d-01,
     &              1.40d-02, 3.25d-02, 9.47d-02, 1.16d-01, 1.16d-01,
c      Lyman delta
     &              6.02d-03, 6.49d-03, 6.61d-03, 5.96d-03, 5.96d-03,
     &              5.93d-03, 6.53d-03, 6.97d-03, 6.85d-03, 6.85d-03,
     &              5.80d-03, 6.46d-03, 7.10d-03, 7.45d-03, 7.45d-03,
     &              5.70d-03, 6.39d-03, 7.11d-03, 7.67d-03, 7.67d-03,
     &              5.63d-03, 6.33d-03, 7.09d-03, 7.79d-03, 7.79d-03,
c      Balmer delta
     &              1.49d-01, 1.61d-01, 1.72d-01, 1.69d-01, 1.69d-01,
     &              1.47d-01, 1.60d-01, 1.74d-01, 1.82d-01, 1.62d-01,
     &              1.43d-01, 1.59d-01, 1.74d-01, 1.89d-01, 1.85d-01,
     &              1.42d-01, 1.55d-01, 1.73d-01, 1.90d-01, 1.90d-01,
     &              1.41d-01, 1.55d-01, 1.71d-01, 1.91d-01, 1.91d-01 /

c ---------------------------------------------------------------------

      width = zero

      if ((ne.le.zero).or.(ni.le.zero)) return

c ... double precision quantum numbers
      pn1 = n1
      pn2 = n2

c ... R. Lee analytic fit for hydrogenic beta and delta lines
c ... (use for helium-like lines as well)
c ... (ref:  R.W.Lee, J. Appl. Phys. 58, p. 612, 1985)
c ... ( -- sign of B parameter is wrong in this paper)
      if ((z.ge.zmin)    .and. (z.le.zmax)   .and.
     &    (ne.le.nemax)  .and.
     &    (tev.ge.tmin)  .and. (tev.le.tmax) .and.
     &    (z-zeff.le.z1) .and. (n1.eq.1)     .and.
     &    ((n2.eq.3).or.(n2.eq.5))                 ) then

         indx = (n2-1)/2
         itab = 1
   90    itab = itab + 1
         if ((tev.gt.ttab(itab)) .and. (itab.lt.ntab)) goto 90
         frac = (ttab(itab)-tev) / (ttab(itab)-ttab(itab-1))

         ai = frac*atab(itab-1,indx) + (one-frac)*atab(itab,indx)
         bi = frac*btab(itab-1,indx) + (one-frac)*btab(itab,indx)
         ci = frac*ctab(itab-1,indx) + (one-frac)*ctab(itab,indx)
         di = frac*dtab(itab-1,indx) + (one-frac)*dtab(itab,indx)

         width = ai * (z/z0)**bi * (ne/ne0)**(ci+(z-z0)*di)

c ... R. Lee analytic fit for hydrogen high-lying Balmer and Paschen lines
c ... (private communication)
c ... ( -- tabulated beta values and multiplier have been adjusted to change
c ...      units on electron density from m^-3 to cm^-3 )
c ... ( -- constant value 2.5d-9 = two*(pi43^two3rd)*qelec
c ...      i.e. width = ai*e/<r>^2 )
      elseif ( z.eq.one                            .and.
     &        (ne.le.nemax2)                       .and.
     &        (tev.ge.tmin2)  .and. (tev.le.tmax2) .and.
     &        ((n1.eq.2).or.(n1.eq.3))             .and.
     &        ((n2.ge.8).and.(n2.le.13))                 ) then
         
         indx = n2-7

c ... Use default Te extrapolation except for 8 -> 2 and 10 -> 2
c ... where explicit tabulation exists
         ai = alptab(indx,n1-1) * 0.7**(log10(tev/ttab2(3)))
         bi = bettab(indx,n1-1) * 0.7**(log10(tev/ttab2(3)))

         if (indx.eq.1 .and. n1.eq.2) then
            itab = 1
   81       itab = itab + 1
            if ((tev.gt.ttab2(itab)) .and. (itab.lt.ntab2)) goto 81
            frac = (ttab2(itab)-tev) / (ttab2(itab)-ttab2(itab-1))
            ai = frac*alp82t(itab-1) + (one-frac)*alp82t(itab)
            bi = frac*bet82t(itab-1) + (one-frac)*bet82t(itab)
         elseif (indx.eq.3 .and. n1.eq.2) then
            itab = 1
   82       itab = itab + 1
            if ((tev.gt.ttab2(itab)) .and. (itab.lt.ntab2)) goto 82
            frac = (ttab2(itab)-tev) / (ttab2(itab)-ttab2(itab-1))
            ai = frac*alp10t(itab-1) + (one-frac)*alp10t(itab)
            bi = frac*bet10t(itab-1) + (one-frac)*bet10t(itab)
         endif

         width = 2.5d-9*(ai*ne**two3rd + bi*ne)

c ... convert from Angstroms to eV
         de = ryd*(zeff+one)**2*(one/pn1**2 - one/pn2**2)
         width = hci*de**2*width
      
c ... Griem numbers for low-lying Hydrogen Lyman and Balmer series
c ... "Spectral line Broadening by Plasmas", p. 314
c ... Book lists HWHMs
      elseif ( z.eq.one                           .and.
     &        (ne.le.1.d20)                       .and.
     &        (tev.ge.tgriem(1).and.
     &         tev.le.tgriem(ngriem))             .and.
     &        ((n1.eq.1).or.(n1.eq.2))            .and.
     &        (n2-n1.le.4)                              ) then

         indx = n2-n1

         itab = 1
   70    itab = itab + 1
         if ((tev.gt.tgriem(itab)) .and. (itab.lt.ngriem)) goto 70
         frac = (tgriem(itab)-tev) / (tgriem(itab)-tgriem(itab-1))
         
         xne = log10(ne)

c ... low density extrapolation:
c ... if delta-n is odd, ai is halved for each density decade below nlo
c ... if delta-n is even, ai is kept constant
         if (xne.lt.nlo(itab-1,n1,indx)) then
            ai =      frac *griem(1,itab-1,n1,indx)
     &         + (one-frac)*griem(1,itab  ,n1,indx)
            if (mod(indx,2).eq.1)
     &	       ai = ai / two**(nlo(itab-1,n1,indx)-xne)
            
c ... no high density extrapolation, ai is constant
         elseif (xne.ge.nhi(itab-1,n1,indx) .or.
     &           xne.ge.nhi(itab,n1,indx)) then
            jtab = max(nhi(itab-1,n1,indx) - nlo(itab-1,n1,indx) + 1,
     &                 nhi(itab  ,n1,indx) - nlo(itab  ,n1,indx) + 1)
            ai   =      frac *griem(jtab,itab-1,n1,indx)
     &         +   (one-frac)*griem(jtab,itab,  n1,indx)

c ... bilinear interpolation on table          
         else
            fx2  = xne - int(xne)
            fx1  = one - fx2
            jtab = int(xne) - nlo(itab-1,n1,indx) + 1
            ai   =      frac *fx1*griem(jtab,  itab-1,n1,indx)
     &           +      frac *fx2*griem(jtab+1,itab-1,n1,indx)
     &           + (one-frac)*fx1*griem(jtab,  itab  ,n1,indx)
     &           + (one-frac)*fx2*griem(jtab+1,itab  ,n1,indx)
         endif
         
         width = 2.5d-9*ai*ne**two3rd

c ... convert from Angstroms to eV
         de = ryd*(zeff+one)**2*(one/pn1**2 - one/pn2**2)
         width = hci*de**2*width

c ... Griem formulas (private communication)
      else
         rzi = a0*(pi43*ni)**third
         rei = a0*(pi43*ne)**third

c ... ion broadening
         f1  = two*ryd/(one + three*z*zbar*ryd*rzi/tiv)
         wd1 = four*zbar *((pn2**2/q2    - pn1**2/q1   )*rzi**2 +
     &                     (pn2**4/q2**2 - pn1**4/q1**2)*rzi**3)  * f1
         wd2 =(six *zbar**2* (pn2**7/q2**3 - pn1**7/q1**3)*rzi**4  +
     &         four*zbar   * (pn2**4/q2**2 - pn1**4/q1**2)*rzi**3 ) * f1

         if (z-zeff.eq.one)  then
            wdion = abs(wd1)
         else
            wdion = max(abs(wd1),abs(wd2))
         endif

c ... electron broadening
         y = (pfq*ne + (q2*ryd/pn2**3)**2) * (pn2**4/q2**2) /
     &       (four*tev*ryd)

         pn = one
         wdelec = nine*sqrt(ryd/(pi*tev))             *
     &               (pn1**4/q1**2 + pn2**4/q2**2)    *
     &               ((three/pn2 + half*exp1x(y))     *
     &                (one - half*pn/pn2**2) + half)  *
     &               (one + half*pn/pn2)              *
     &               (ryd*rei**3)

         width = wdion + wdelec

         if (mod(n2-n1,2).eq.1) then
            width = 0.25d0*width
         endif

      endif

c ... compute the distance to the next line in this sequence
      wnext = ryd*zeff**2*(two*pn2+one)/pn2**2
      width = min(width,wnext)

c ... compute the (hydrogenic) fine-structure spacing
      if (z.eq.one) then
         demin = zero
         demax = zero
         do 110 j2 = 1,2*n2-1,2
            do 100 j1 = j2-2,j2+2,2
               if (j1.le.(2*n1-1) .and. j1.ge.1) then
                  defs = (one + (two*n1/(j1+1) - 0.75d0)) / n1**4 -
     &                   (one + (two*n2/(j2+1) - 0.75d0)) / n2**4
                  demax = max(demax,defs)
                  demin = min(demin,defs)
               endif
  100       continue
  110    continue

         wfine = (demax-demin)*ryd*(zeff+one)**2 / alphai**2
         width = max(width,wfine)
      endif

      return
      end

c *********************************************************************
