"""Plot the example spectrum (2_spectrum/sp001xout) against the expected results.

usage: python3 plot_spectrum.py [sp_file]     (default: 2_spectrum/sp001xout)
writes spectrum_check.png
"""
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

here = os.path.dirname(os.path.abspath(__file__))
spfile = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "2_spectrum", "sp001xout")

def read_sp(fn):
    # sp file columns: E, intensity, blackbody, eps_total, eps_bb, eps_bf, eps_ff, eps_bb per ion
    return np.loadtxt(fn, comments="#", usecols=(0, 3))

fig, ax = plt.subplots(figsize=(9, 5), dpi=150)
ref = os.path.join(here, "expected", "flychk_flyspec_te30_ne1e20.dat")
if os.path.exists(ref):
    r = np.loadtxt(ref, usecols=(0, 1))
    ax.semilogy(r[:, 0], r[:, 1], color="#9aa0a6", lw=2.2, label="FLYCHK + FLYSPEC (reference)")
exp = os.path.join(here, "expected", "sp001xout")
if os.path.exists(exp) and os.path.abspath(exp) != os.path.abspath(spfile):
    e = read_sp(exp)
    ax.semilogy(e[:, 0], e[:, 1], color="#2a78d6", lw=1.4, label="expected: SCFLY + scflyspec_xrn")
s = read_sp(spfile)
ax.semilogy(s[:, 0], s[:, 1], color="#e8743b", lw=1.0, ls="--", label=f"this run: {os.path.basename(spfile)}")
m = (s[:, 0] >= 5) & (s[:, 0] <= 300)
ax.set_xlim(5, 300)
ax.set_ylim(s[m, 1].min() / 3, s[m, 1].max() * 3)
ax.set_xlabel("Photon energy (eV)")
ax.set_ylabel("total emissivity")
ax.set_title("Cu, Te = 30 eV, Ne = 1e20 cm$^{-3}$, steady state")
ax.grid(True, color="#e6e6e6", lw=0.6)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
out = os.path.join(here, "spectrum_check.png")
fig.savefig(out)
print("wrote", out)
