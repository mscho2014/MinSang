#!/bin/bash
# Step 2: spectrum from the step-1 populations with the xrn.29 line list.
set -e
cd "$(dirname "$0")"
ln -sf ../1_scfly/xout xout
for f in xrn.29 phistuf flychk_levels.29; do ln -sf ../../data/$f $f; done
../../src/scflyspec_xrn > spectrum.log 2>&1
echo "done: sp001xout (spectrum), bb001xout (lines), bf001xout (bound-free), op001xout (opacity)"
grep -E "xrn|skipped|ion:" spectrum.log
