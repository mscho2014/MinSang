#!/bin/bash
# Step 1: SCFLY steady-state Cu populations with the FLYCHK-structure atomic data.
# usage: ./run.sh /path/to/scfly        (SCFLY executable from your SCFLY build)
set -e
SCFLY=${1:?usage: ./run.sh /path/to/scfly}
cd "$(dirname "$0")"
ln -sf ../../data/atomic.inp.29 atomic.inp.29
"$SCFLY" runfile > scfly.log 2>&1
echo "done: xout written (Zbar in zb.xout)"
cat zb.xout
